# ERP Didático 2026: versão com Banco de Dados

Este ERP guarda produtos, pessoas, pedidos, títulos e usuários em um banco de dados **PostgreSQL**. Cada pessoa precisa do **próprio banco, instalado no próprio computador**, com a **própria senha**. O banco não vai junto com o projeto.

## 1. O que você precisa instalar

| Programa | Observação |
|---|---|
| **JDK 17 ou mais novo** | O projeto foi desenvolvido com JDK 17. |
| **IntelliJ IDEA** | Community ou Ultimate. |
| **PostgreSQL** | Versão 16 ou mais nova (testado na 18). Baixe em postgresql.org/download/windows e mantenha marcados *PostgreSQL Server*, *pgAdmin 4* e *Command Line Tools*. |

Durante a instalação do PostgreSQL:
- Defina a **senha do usuário `postgres`** e **anote-a**. Você vai usá-la no passo 3.
- Mantenha a porta **5432**.

O driver de conexão (`lib\postgresql-42.7.14.jar`) já vem na pasta `lib`. Você não precisa baixá-lo.

## 2. Criar o banco vazio

1. Abra o **pgAdmin 4** e conecte ao servidor (ele pede a senha do `postgres`).
2. Clique com o botão direito em **Databases → Create → Database…**
3. No campo **Database**, digite exatamente `erp_didatico` e clique em **Save**.

Não é preciso criar tabelas: o migrador (passo 5) as cria sozinho.

## 3. Guardar a senha em uma variável de ambiente (nunca no código)

O ERP lê a senha da variável **`ERP_DB_PASS`**. A senha **não deve ser escrita em nenhum arquivo do projeto**.

**Windows:**
1. Aperte a tecla Windows e digite *variáveis de ambiente* → **Editar as variáveis de ambiente do sistema**.
2. Clique em **Variáveis de Ambiente…**
3. Em **Variáveis de usuário**, clique em **Novo…**
4. **Nome:** `ERP_DB_PASS`. **Valor:** a senha do seu `postgres`, sem aspas.
5. **OK** nas três janelas e **feche o IntelliJ por completo**. Ele só enxerga a variável depois de reiniciar.

**Linux / Mac:** adicione `export ERP_DB_PASS="sua_senha"` ao `~/.bashrc` ou `~/.zshrc` e abra um novo terminal.

Variáveis opcionais (só se o seu PostgreSQL for diferente do padrão):

| Variável | Padrão |
|---|---|
| `ERP_DB_USER` | `postgres` |

## 4. Abrir o projeto no IntelliJ

1. **File → Open** e escolha a pasta `ERPDidatico2026 1.13b`.
2. Se o IntelliJ avisar que o JDK `ms-17` não existe, vá em **File → Project Structure → Project** e escolha o JDK que você instalou.
3. Confira em **Project Structure → Modules** que `ERPDidatico2026\src` aparece como **Sources** (azul). Se não aparecer, clique com o botão direito em `src` → **Mark Directory as → Sources Root**.
4. Confira em **External Libraries** que existe `postgresql-42.7.14`. Se não existir: **Project Structure → Libraries → + → Java** e selecione `lib\postgresql-42.7.14.jar`. Depois, em **Modules → Dependencies**, confirme que ele aparece como **Compile**.
5. Pode aparecer um aviso amarelo de biblioteca duplicada (`lib` e `lib (2)`). É inofensivo.

## 5. Criar as configurações de execução

Em **Run → Edit Configurations… → + → Application**, crie três:

| Name | Main class |
|---|---|
| `TesteConexao` | `com.erp.TesteConexao` |
| `MigradorTxt` | `com.erp.MigradorTxt` |
| `Main` | `com.erp.Main` |

Em cada uma:
- **Working directory:** a pasta raiz do projeto (`...\ERPDidatico2026 1.13b`), onde estão `produtos.txt`, `textos_pt.txt` etc. Se estiver errada, o ERP não acha os arquivos.
- **Environment variables:** deixe **vazio**. A senha vem do Windows (passo 3).
- Se o campo do módulo/classpath não aparecer, clique em **Modify options** e marque **Use classpath of module**.

## 6. Testar a conexão

Rode o **TesteConexao**. O console deve mostrar `Conectado! PostgreSQL ...`. Se aparecer erro, veja a seção 9 antes de continuar.

## 7. Migrar os dados dos `.txt` para o banco (uma única vez)

Rode o **MigradorTxt**. Ele cria as tabelas e copia os dados. O histórico de vendas tem cerca de 500 mil linhas e pode levar de alguns segundos a poucos minutos. No final ele imprime a contagem de cada tabela, que deve ser aproximadamente:

| Tabela | Linhas esperadas |
|---|---|
| `produto` | cerca de 50 mil |
| `pessoa` | 6 |
| `pedido` | cerca de 560 |
| `item_pedido` | vários centenas |
| `historico_venda` | cerca de 500 mil |

Para conferir no pgAdmin (**Query Tool** do `erp_didatico`, tecla **F5**):

```sql
SELECT 'produto' AS tabela, COUNT(*) FROM produto
UNION ALL SELECT 'pessoa', COUNT(*) FROM pessoa
UNION ALL SELECT 'pedido', COUNT(*) FROM pedido
UNION ALL SELECT 'item_pedido', COUNT(*) FROM item_pedido
UNION ALL SELECT 'titulo', COUNT(*) FROM titulo
UNION ALL SELECT 'usuario', COUNT(*) FROM usuario
UNION ALL SELECT 'historico_venda', COUNT(*) FROM historico_venda;
```

Observações:
- Rodar o migrador de novo **não duplica** produtos, pessoas, pedidos nem títulos (ele ignora o que já existe). O histórico só é carregado se a tabela estiver vazia.
- O argumento `limpar` (em **Program arguments**) **apaga todas as tabelas e recarrega dos `.txt`**. Use somente para refazer do zero, pois as vendas feitas depois da migração se perdem.
- Se não houver `usuarios.txt` na pasta, o migrador avisa e segue. Os usuários de teste são criados no primeiro `Main` (passo 8).

## 8. Rodar o ERP

Rode o **Main**. Na primeira execução, com a tabela de usuários vazia, o ERP cria:

| Usuário | Senha | Papel |
|---|---|---|
| `admin` | `admin123` | Admin |
| `operador` | `operador123` | Operador |

São senhas **públicas de teste**. Use o ERP apenas na sua máquina.

Para confirmar que ele grava no banco, faça uma venda no ERP e depois rode no pgAdmin:

```sql
SELECT * FROM pedido ORDER BY seq DESC LIMIT 5;
```

O pedido novo deve aparecer na primeira linha.

## 9. O que está no banco e o que continua em arquivo

| No PostgreSQL | Continua em arquivo (na pasta raiz) |
|---|---|
| Produtos, pessoas, pedidos e itens, títulos, usuários | `textos_pt.txt`, `textos_de.txt`, `glossario_traducoes.csv` (traduções e configuração) |
| Tabela `historico_venda` (carregada, mas o ERP ainda lê o arquivo) | `historico_vendas.txt`, `projetos.txt`, `aprovacoes.txt`, `seguranca_tentativas.txt`, `auditoria.log` |

Por isso **não apague nem mova** esses arquivos. Os `.txt` de produtos, pessoas, pedidos e títulos deixam de ser usados depois da migração e ficam apenas como cópia do estado inicial.
