package com.erp;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class MigradorTxt {

    private static final int LOTE = 5000;

    private static final String[] TABELAS = {
            "item_pedido", "pedido", "titulo", "historico_venda", "produto", "pessoa", "usuario"
    };

    public static void main(String[] args) {
        boolean limpar = args.length > 0 && args[0].equalsIgnoreCase("limpar");
        long inicio = System.currentTimeMillis();

        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            criarTabelas(c);
            if (limpar) {
                limparTabelas(c);
            }

            migrarUsuarios(c);
            Set<String> pessoas = migrarPessoas(c);
            Set<String> produtos = migrarProdutos(c);
            migrarTitulos(c, pessoas);
            migrarPedidos(c, pessoas, produtos);
            migrarHistorico(c);

            System.out.println();
            System.out.println("Migração concluída em " + (System.currentTimeMillis() - inicio) / 1000.0 + " s.");
            conferir(c);
        } catch (Exception e) {
            System.out.println("Falha na migração: " + e.getMessage());
            e.printStackTrace(System.out);
        }
    }

    private static void criarTabelas(Connection c) throws SQLException {
        String[] ddl = {
                "CREATE TABLE IF NOT EXISTS pessoa (id VARCHAR(20) PRIMARY KEY, tipo INT NOT NULL, "
                        + "nome VARCHAR(200) NOT NULL, base_legal VARCHAR(100), segmento VARCHAR(50) DEFAULT '')",
                "CREATE TABLE IF NOT EXISTS produto (id VARCHAR(20) PRIMARY KEY, nome VARCHAR(200) NOT NULL, "
                        + "preco NUMERIC(12,2) NOT NULL, quantidade INT NOT NULL, categoria VARCHAR(100) DEFAULT '')",
                "CREATE TABLE IF NOT EXISTS pedido (id VARCHAR(20) PRIMARY KEY, "
                        + "cliente_id VARCHAR(20) REFERENCES pessoa(id), data VARCHAR(20) NOT NULL)",
                "CREATE TABLE IF NOT EXISTS item_pedido (pedido_id VARCHAR(20) REFERENCES pedido(id) ON DELETE CASCADE, "
                        + "produto_id VARCHAR(20) REFERENCES produto(id), quantidade INT NOT NULL, "
                        + "preco_unitario NUMERIC(12,2) NOT NULL, PRIMARY KEY (pedido_id, produto_id))",
                "CREATE TABLE IF NOT EXISTS titulo (id VARCHAR(50) PRIMARY KEY, valor NUMERIC(12,2) NOT NULL, "
                        + "paga BOOLEAN NOT NULL, pessoa_id VARCHAR(20) REFERENCES pessoa(id), "
                        + "tipo_titulo VARCHAR(20) NOT NULL)",
                "CREATE TABLE IF NOT EXISTS usuario (username VARCHAR(50) PRIMARY KEY, senha_hash TEXT NOT NULL, "
                        + "role VARCHAR(30) NOT NULL, idioma VARCHAR(5) DEFAULT 'pt', "
                        + "gerente_funcional VARCHAR(50) DEFAULT '', gerente_projeto VARCHAR(50) DEFAULT '')",
                "CREATE TABLE IF NOT EXISTS historico_venda (id BIGSERIAL PRIMARY KEY, produto_id VARCHAR(20) NOT NULL, "
                        + "quantidade INT NOT NULL, data DATE NOT NULL)",
                "CREATE INDEX IF NOT EXISTS idx_hist_produto ON historico_venda(produto_id)"
        };
        try (Statement st = c.createStatement()) {
            for (String sql : ddl) {
                st.execute(sql);
            }
        }
        c.commit();
    }

    private static void limparTabelas(Connection c) throws SQLException {
        try (Statement st = c.createStatement()) {
            st.execute("TRUNCATE " + String.join(", ", TABELAS) + " RESTART IDENTITY CASCADE");
        }
        c.commit();
        System.out.println("Tabelas limpas.");
    }

    private static int contar(Connection c, String tabela) throws SQLException {
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + tabela)) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private static void migrarUsuarios(Connection c) throws Exception {
        File f = new File("usuarios.txt");
        if (!f.exists()) { System.out.println("usuarios.txt não encontrado, pulando."); return; }
        String sql = "INSERT INTO usuario (username, senha_hash, role, idioma, gerente_funcional, gerente_projeto) "
                + "VALUES (?,?,?,?,?,?) ON CONFLICT (username) DO NOTHING";
        int ok = 0, ruins = 0;
        try (PreparedStatement ps = c.prepareStatement(sql); BufferedReader r = abrir(f)) {
            String linha;
            while ((linha = r.readLine()) != null) {
                if (linha.isBlank()) continue;
                try {
                    Usuario u = Usuario.fromString(linha);
                    ps.setString(1, u.getUsername());
                    ps.setString(2, u.getSenhaHash());
                    ps.setString(3, u.getRole());
                    ps.setString(4, u.getIdioma());
                    ps.setString(5, u.getGerenteFuncional());
                    ps.setString(6, u.getGerenteProjeto());
                    ps.addBatch();
                    ok++;
                } catch (Exception e) { ruins++; }
            }
            ps.executeBatch();
        }
        c.commit();
        System.out.println("usuario: lidos " + ok + ", linhas inválidas " + ruins);
    }

    private static Set<String> migrarPessoas(Connection c) throws Exception {
        Set<String> ids = new HashSet<>();
        File f = new File("pessoas.txt");
        if (f.exists()) {
            String sql = "INSERT INTO pessoa (id, tipo, nome, base_legal, segmento) VALUES (?,?,?,?,?) "
                    + "ON CONFLICT (id) DO NOTHING";
            int ok = 0, ruins = 0;
            try (PreparedStatement ps = c.prepareStatement(sql); BufferedReader r = abrir(f)) {
                String linha;
                while ((linha = r.readLine()) != null) {
                    if (linha.isBlank()) continue;
                    try {
                        Pessoa p = Pessoa.fromString(linha);
                        ps.setString(1, p.getId());
                        ps.setInt(2, p.getTipo());
                        ps.setString(3, p.getNome());
                        ps.setString(4, p.getBaseLegal());
                        ps.setString(5, p.getSegmento());
                        ps.addBatch();
                        ids.add(p.getId());
                        ok++;
                    } catch (Exception e) { ruins++; }
                }
                ps.executeBatch();
            }
            c.commit();
            System.out.println("pessoa: lidas " + ok + ", linhas inválidas " + ruins);
        }
        return ids;
    }

    private static Set<String> migrarProdutos(Connection c) throws Exception {
        Set<String> ids = new HashSet<>();
        File f = new File("produtos.txt");
        if (!f.exists()) { System.out.println("produtos.txt não encontrado, pulando."); return ids; }
        String sql = "INSERT INTO produto (id, nome, preco, quantidade, categoria) VALUES (?,?,?,?,?) "
                + "ON CONFLICT (id) DO NOTHING";
        int lidos = 0, ruins = 0, noLote = 0;
        try (PreparedStatement ps = c.prepareStatement(sql); BufferedReader r = abrir(f)) {
            String linha;
            while ((linha = r.readLine()) != null) {
                if (linha.isBlank()) continue;
                try {
                    Produto p = Produto.fromString(linha);
                    ps.setString(1, p.getId());
                    ps.setString(2, p.getNome());
                    ps.setBigDecimal(3, p.getPreco());
                    ps.setInt(4, p.getQuantidade());
                    ps.setString(5, p.getCategoria());
                    ps.addBatch();
                    ids.add(p.getId());
                    lidos++;
                    if (++noLote >= LOTE) { ps.executeBatch(); noLote = 0; }
                } catch (Exception e) { ruins++; }
            }
            ps.executeBatch();
        }
        c.commit();
        System.out.println("produto: lidos " + lidos + ", linhas inválidas " + ruins
                + ", ids distintos " + ids.size());
        return ids;
    }

    private static void migrarTitulos(Connection c, Set<String> pessoas) throws Exception {
        File f = new File("titulos.txt");
        if (!f.exists()) { System.out.println("titulos.txt não encontrado, pulando."); return; }
        String sql = "INSERT INTO titulo (id, valor, paga, pessoa_id, tipo_titulo) VALUES (?,?,?,?,?) "
                + "ON CONFLICT (id) DO NOTHING";
        int ok = 0, ruins = 0, orfaos = 0;
        try (PreparedStatement ps = c.prepareStatement(sql); BufferedReader r = abrir(f)) {
            String linha;
            while ((linha = r.readLine()) != null) {
                if (linha.isBlank()) continue;
                try {
                    Titulo t = Titulo.fromString(linha);
                    if (!pessoas.contains(t.getPessoaId())) { orfaos++; continue; }
                    ps.setString(1, t.getId());
                    ps.setBigDecimal(2, t.getQuantidade());
                    ps.setBoolean(3, t.isPago());
                    ps.setString(4, t.getPessoaId());
                    ps.setString(5, t.getTipoTitulo());
                    ps.addBatch();
                    ok++;
                } catch (Exception e) { ruins++; }
            }
            ps.executeBatch();
        }
        c.commit();
        System.out.println("titulo: lidos " + ok + ", sem pessoa correspondente " + orfaos
                + ", linhas inválidas " + ruins);
    }

    private static void migrarPedidos(Connection c, Set<String> pessoas, Set<String> produtos) throws Exception {
        File f = new File("pedidos.txt");
        if (!f.exists()) { System.out.println("pedidos.txt não encontrado, pulando."); return; }
        String sqlPedido = "INSERT INTO pedido (id, cliente_id, data) VALUES (?,?,?) ON CONFLICT (id) DO NOTHING";
        String sqlItem = "INSERT INTO item_pedido (pedido_id, produto_id, quantidade, preco_unitario) "
                + "VALUES (?,?,?,?) ON CONFLICT (pedido_id, produto_id) DO NOTHING";
        int pedidos = 0, itens = 0, ruins = 0, pedidosOrfaos = 0, itensOrfaos = 0;
        try (PreparedStatement psP = c.prepareStatement(sqlPedido);
             PreparedStatement psI = c.prepareStatement(sqlItem);
             BufferedReader r = abrir(f)) {
            String linha;
            while ((linha = r.readLine()) != null) {
                if (linha.isBlank()) continue;
                try {
                    Pedido p = Pedido.fromString(linha);
                    if (!pessoas.contains(p.getClienteId())) { pedidosOrfaos++; continue; }
                    psP.setString(1, p.getId());
                    psP.setString(2, p.getClienteId());
                    psP.setString(3, p.getData());
                    psP.addBatch();
                    pedidos++;
                    for (ItemPedido it : p.getItens()) {
                        if (!produtos.contains(it.getProdutoId())) { itensOrfaos++; continue; }
                        psI.setString(1, p.getId());
                        psI.setString(2, it.getProdutoId());
                        psI.setInt(3, it.getQuantidade());
                        psI.setBigDecimal(4, it.getPrecoUnitario());
                        psI.addBatch();
                        itens++;
                    }
                } catch (Exception e) { ruins++; }
            }
            psP.executeBatch();   // pedidos primeiro, por causa da chave estrangeira dos itens
            psI.executeBatch();
        }
        c.commit();
        System.out.println("pedido: " + pedidos + " (sem cliente: " + pedidosOrfaos + "), item_pedido: " + itens
                + " (produto inexistente: " + itensOrfaos + "), linhas inválidas " + ruins);
    }

    private static void migrarHistorico(Connection c) throws Exception {
        File f = new File("historico_vendas.txt");
        if (!f.exists()) { System.out.println("historico_vendas.txt não encontrado, pulando."); return; }
        if (contar(c, "historico_venda") > 0) {
            System.out.println("historico_venda já tem dados, pulando (rode com o argumento 'limpar' para refazer).");
            return;
        }
        String sql = "INSERT INTO historico_venda (produto_id, quantidade, data) VALUES (?,?,?)";
        long lidos = 0, ruins = 0;
        int noLote = 0;
        try (PreparedStatement ps = c.prepareStatement(sql); BufferedReader r = abrir(f)) {
            String linha;
            while ((linha = r.readLine()) != null) {
                if (linha.isBlank()) continue;
                try {
                    String[] p = linha.split(",");
                    ps.setString(1, p[0].trim());
                    ps.setInt(2, Integer.parseInt(p[1].trim()));
                    ps.setDate(3, Date.valueOf(LocalDate.parse(p[2].trim())));
                    ps.addBatch();
                    lidos++;
                    if (++noLote >= LOTE) {
                        ps.executeBatch();
                        noLote = 0;
                        if (lidos % 100000 == 0) System.out.println("  historico_venda: " + lidos + " linhas...");
                    }
                } catch (Exception e) { ruins++; }
            }
            ps.executeBatch();
        }
        c.commit();
        System.out.println("historico_venda: lidas " + lidos + ", linhas inválidas " + ruins);
    }

    private static void conferir(Connection c) throws SQLException {
        System.out.println("--- Contagem no banco ---");
        for (String t : new String[]{"usuario", "pessoa", "produto", "titulo", "pedido", "item_pedido", "historico_venda"}) {
            System.out.printf("%-16s %d%n", t, contar(c, t));
        }
    }

    private static BufferedReader abrir(File f) throws IOException {
        return Files.newBufferedReader(f.toPath(), StandardCharsets.UTF_8);
    }
}