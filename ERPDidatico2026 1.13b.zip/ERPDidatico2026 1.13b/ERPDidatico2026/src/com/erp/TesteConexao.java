package com.erp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TesteConexao {
    public static void main(String[] args) {
        try (Connection c = Banco.conectar();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT version()")) {
            rs.next();
            System.out.println("Conectado! " + rs.getString(1));
        } catch (Exception e) {
            System.out.println("Falha na conexão: " + e.getMessage());
        }
    }
}