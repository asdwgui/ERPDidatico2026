package com.erp;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RepositorioBanco {

    private static boolean preparado = false;

    private static synchronized void preparar(Connection c) throws SQLException {
        if (preparado) return;
        try (Statement st = c.createStatement()) {
            for (String t : new String[]{"pessoa", "produto", "titulo", "pedido", "item_pedido", "usuario"}) {
                st.execute("ALTER TABLE " + t + " ADD COLUMN IF NOT EXISTS seq BIGSERIAL");
            }
        }
        preparado = true;
    }

    private static IOException erro(String acao, SQLException e) {
        return new IOException("Erro no banco ao " + acao + ": " + e.getMessage(), e);
    }

    // PRODUTOS

    public static List<Produto> carregarProdutos() throws IOException {
        List<Produto> lista = new ArrayList<>();
        try (Connection c = Banco.conectar()) {
            preparar(c);
            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery(
                         "SELECT id, nome, preco, quantidade, categoria FROM produto ORDER BY seq")) {
                while (rs.next()) {
                    lista.add(new Produto(rs.getString(1), rs.getString(2), rs.getBigDecimal(3),
                            rs.getInt(4), rs.getString(5)));
                }
            }
        } catch (SQLException e) {
            throw erro("carregar produtos", e);
        }
        return lista;
    }

    public static void salvarProdutos(List<Produto> produtos) throws IOException {
        String sql = "INSERT INTO produto (id, nome, preco, quantidade, categoria) VALUES (?,?,?,?,?) "
                + "ON CONFLICT (id) DO UPDATE SET nome = EXCLUDED.nome, preco = EXCLUDED.preco, "
                + "quantidade = EXCLUDED.quantidade, categoria = EXCLUDED.categoria "
                + "WHERE (produto.nome, produto.preco, produto.quantidade, produto.categoria) "
                + "IS DISTINCT FROM (EXCLUDED.nome, EXCLUDED.preco, EXCLUDED.quantidade, EXCLUDED.categoria)";
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                int lote = 0;
                for (Produto p : produtos) {
                    ps.setString(1, p.getId());
                    ps.setString(2, p.getNome());
                    ps.setBigDecimal(3, p.getPreco());
                    ps.setInt(4, p.getQuantidade());
                    ps.setString(5, p.getCategoria() == null ? "" : p.getCategoria());
                    ps.addBatch();
                    if (++lote >= 5000) { ps.executeBatch(); lote = 0; }
                }
                ps.executeBatch();
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw erro("salvar produtos", e);
        }
    }

    // PESSOAS

    public static List<Pessoa> carregarPessoas() throws IOException {
        List<Pessoa> lista = new ArrayList<>();
        try (Connection c = Banco.conectar()) {
            preparar(c);
            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery(
                         "SELECT id, tipo, nome, base_legal, segmento FROM pessoa ORDER BY seq")) {
                while (rs.next()) {
                    lista.add(new Pessoa(rs.getString(1), rs.getInt(2), rs.getString(3),
                            rs.getString(4), rs.getString(5)));
                }
            }
        } catch (SQLException e) {
            throw erro("carregar pessoas", e);
        }
        return lista;
    }

    public static void salvarPessoas(List<Pessoa> pessoas) throws IOException {
        String sql = "INSERT INTO pessoa (id, tipo, nome, base_legal, segmento) VALUES (?,?,?,?,?) "
                + "ON CONFLICT (id) DO UPDATE SET tipo = EXCLUDED.tipo, nome = EXCLUDED.nome, "
                + "base_legal = EXCLUDED.base_legal, segmento = EXCLUDED.segmento";
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                for (Pessoa p : pessoas) {
                    ps.setString(1, p.getId());
                    ps.setInt(2, p.getTipo());
                    ps.setString(3, p.getNome());
                    ps.setString(4, p.getBaseLegal());
                    ps.setString(5, p.getSegmento() == null ? "" : p.getSegmento());
                    ps.addBatch();
                }
                ps.executeBatch();
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw erro("salvar pessoas", e);
        }
    }

    // USUÁRIOS

    public static List<Usuario> carregarUsuarios() throws IOException {
        List<Usuario> lista = new ArrayList<>();
        try (Connection c = Banco.conectar()) {
            preparar(c);
            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery(
                         "SELECT username, senha_hash, role, idioma, gerente_funcional, gerente_projeto "
                                 + "FROM usuario ORDER BY seq")) {
                while (rs.next()) {
                    lista.add(new Usuario(rs.getString(1), rs.getString(2), rs.getString(3),
                            rs.getString(4), rs.getString(5), rs.getString(6)));
                }
            }
        } catch (SQLException e) {
            throw erro("carregar usuários", e);
        }
        return lista;
    }

    public static void salvarUsuarios(List<Usuario> usuarios) throws IOException {
        String sql = "INSERT INTO usuario (username, senha_hash, role, idioma, gerente_funcional, gerente_projeto) "
                + "VALUES (?,?,?,?,?,?) ON CONFLICT (username) DO UPDATE SET senha_hash = EXCLUDED.senha_hash, "
                + "role = EXCLUDED.role, idioma = EXCLUDED.idioma, "
                + "gerente_funcional = EXCLUDED.gerente_funcional, gerente_projeto = EXCLUDED.gerente_projeto";
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                for (Usuario u : usuarios) {
                    ps.setString(1, u.getUsername());
                    ps.setString(2, u.getSenhaHash());
                    ps.setString(3, u.getRole());
                    ps.setString(4, u.getIdioma());
                    ps.setString(5, u.getGerenteFuncional() == null ? "" : u.getGerenteFuncional());
                    ps.setString(6, u.getGerenteProjeto() == null ? "" : u.getGerenteProjeto());
                    ps.addBatch();
                }
                ps.executeBatch();
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw erro("salvar usuários", e);
        }
    }

    // TÍTULOS

    public static List<Titulo> carregarTitulos() throws IOException {
        List<Titulo> lista = new ArrayList<>();
        try (Connection c = Banco.conectar()) {
            preparar(c);
            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery(
                         "SELECT id, valor, paga, pessoa_id, tipo_titulo FROM titulo ORDER BY seq")) {
                while (rs.next()) {
                    lista.add(new Titulo(rs.getString(1), rs.getBigDecimal(2), rs.getBoolean(3),
                            rs.getString(4), rs.getString(5)));
                }
            }
        } catch (SQLException e) {
            throw erro("carregar títulos", e);
        }
        return lista;
    }

    public static void salvarTitulos(List<Titulo> titulos) throws IOException {
        String sql = "INSERT INTO titulo (id, valor, paga, pessoa_id, tipo_titulo) VALUES (?,?,?,?,?) "
                + "ON CONFLICT (id) DO UPDATE SET valor = EXCLUDED.valor, paga = EXCLUDED.paga, "
                + "pessoa_id = EXCLUDED.pessoa_id, tipo_titulo = EXCLUDED.tipo_titulo";
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                for (Titulo t : titulos) {
                    ps.setString(1, t.getId());
                    ps.setBigDecimal(2, t.getQuantidade());
                    ps.setBoolean(3, t.isPago());
                    ps.setString(4, t.getPessoaId());
                    ps.setString(5, t.getTipoTitulo());
                    ps.addBatch();
                }
                ps.executeBatch();
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw erro("salvar títulos", e);
        }
    }

    // PEDIDOS

    public static List<Pedido> carregarPedidos() throws IOException {
        List<Pedido> lista = new ArrayList<>();
        Map<String, Pedido> porId = new HashMap<>();
        try (Connection c = Banco.conectar()) {
            preparar(c);
            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery("SELECT id, cliente_id, data FROM pedido ORDER BY seq")) {
                while (rs.next()) {
                    Pedido p = new Pedido(rs.getString(1), rs.getString(2), rs.getString(3));
                    lista.add(p);
                    porId.put(p.getId(), p);
                }
            }
            try (Statement st = c.createStatement();
                 ResultSet rs = st.executeQuery(
                         "SELECT pedido_id, produto_id, quantidade, preco_unitario FROM item_pedido ORDER BY seq")) {
                while (rs.next()) {
                    Pedido p = porId.get(rs.getString(1));
                    if (p != null) {
                        p.adicionarItem(new ItemPedido(rs.getString(2), rs.getInt(3), rs.getBigDecimal(4)));
                    }
                }
            }
        } catch (SQLException e) {
            throw erro("carregar pedidos", e);
        }
        return lista;
    }

    public static void salvarPedidos(List<Pedido> pedidos) throws IOException {
        String sqlPedido = "INSERT INTO pedido (id, cliente_id, data) VALUES (?,?,?) "
                + "ON CONFLICT (id) DO UPDATE SET cliente_id = EXCLUDED.cliente_id, data = EXCLUDED.data";
        String sqlApagaItens = "DELETE FROM item_pedido WHERE pedido_id = ?";
        String sqlItem = "INSERT INTO item_pedido (pedido_id, produto_id, quantidade, preco_unitario) "
                + "VALUES (?,?,?,?)";
        try (Connection c = Banco.conectar()) {
            c.setAutoCommit(false);
            try (PreparedStatement psP = c.prepareStatement(sqlPedido);
                 PreparedStatement psD = c.prepareStatement(sqlApagaItens);
                 PreparedStatement psI = c.prepareStatement(sqlItem)) {
                for (Pedido p : pedidos) {
                    psP.setString(1, p.getId());
                    psP.setString(2, p.getClienteId());
                    psP.setString(3, p.getData());
                    psP.addBatch();
                    psD.setString(1, p.getId());
                    psD.addBatch();
                    for (ItemPedido it : p.getItens()) {
                        psI.setString(1, p.getId());
                        psI.setString(2, it.getProdutoId());
                        psI.setInt(3, it.getQuantidade());
                        psI.setBigDecimal(4, it.getPrecoUnitario());
                        psI.addBatch();
                    }
                }
                psP.executeBatch();
                psD.executeBatch();
                psI.executeBatch();
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw erro("salvar pedidos", e);
        }
    }
}