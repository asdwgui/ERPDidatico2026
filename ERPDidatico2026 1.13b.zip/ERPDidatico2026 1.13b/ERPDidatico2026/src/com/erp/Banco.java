package com.erp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Banco {

    private static final String URL =
            System.getenv().getOrDefault("ERP_DB_URL",
                    "jdbc:postgresql://localhost:5432/erp_didatico?reWriteBatchedInserts=true");
    private static final String USUARIO =
            System.getenv().getOrDefault("ERP_DB_USER", "postgres");
    private static final String SENHA = System.getenv("ERP_DB_PASS");

    public static Connection conectar() throws SQLException {
        if (SENHA == null || SENHA.isBlank()) {
            throw new SQLException("Variável de ambiente ERP_DB_PASS não definida.");
        }
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}