package com.erp;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// DESAFIO 13: gera histórico de vendas para o painel ter o que mostrar.
//
// Um painel de BI sobre uma base vazia não prova nada - mostra zero em toda
// parte. O pedidos.txt do ERP tem pouquíssimas linhas, então esta classe cria
// seis meses de vendas usando os produtos e clientes que JÁ EXISTEM no sistema.
//
// Três cuidados que fazem os números significarem alguma coisa:
//
//   1. TENDÊNCIA. As vendas crescem devagar ao longo dos seis meses. Sem isso a
//      previsão não teria o que encontrar e daria sempre a média.
//
//   2. SAZONALIDADE. Fim de semana vende menos. É o que faz a série parecer
//      dados reais em vez de uma reta.
//
//   3. CONCENTRAÇÃO. Poucos produtos respondem pela maior parte do faturamento.
//      É isso que a curva ABC existe para revelar - e, se as vendas fossem
//      distribuídas por igual, a curva não mostraria nada.
//
// Como rodar: abra este arquivo e clique na seta verde ao lado do main.
// Tudo o que ele cria tem ID começando com "H", então é fácil apagar depois.
public class GeradorVendas {

    private static final int DIAS = 180;
    private static final int PEDIDOS_POR_DIA_BASE = 3;

    public static void main(String[] args) throws IOException {
        Estoque estoque = new Estoque();

        List<Produto> produtos = new ArrayList<>();
        for (Produto p : estoque.getProdutos()) {
            if (!p.getId().startsWith("H")) {
                produtos.add(p);
            }
        }
        List<Pessoa> clientes = estoque.getClientes();

        if (produtos.isEmpty() || clientes.isEmpty()) {
            Console.aviso("Cadastre pelo menos um produto e um cliente antes.");
            return;
        }

        Medicao medicao = Medicao.iniciar("gerar " + DIAS + " dias de vendas");
        int pedidos = gerar(produtos, clientes);
        medicao.encerrar();

        Console.linha();
        System.out.printf("%-40s %d%n", "Pedidos gerados", pedidos);
        System.out.printf("%-40s %d%n", "Dias cobertos", DIAS);
        System.out.printf("%-40s %d%n", "Produtos usados", produtos.size());
        System.out.printf("%-40s %d%n", "Clientes usados", clientes.size());
        Console.linha();
        System.out.println("Agora rode o TestePainelBI, ou abra o ERP na opção 25.");
        System.out.println();
        System.out.println("Para voltar ao normal: apague do pedidos.txt e do");
        System.out.println("historico_vendas.txt as linhas que começam com H.");
    }

    private static int gerar(List<Produto> produtos, List<Pessoa> clientes) throws IOException {
        Random sorteio = new Random(13); // semente fixa: todos geram a mesma base
        LocalDate hoje = LocalDate.now();
        int contador = 0;

        // Os produtos são sorteados com peso: os primeiros da lista vendem muito
        // mais que os últimos. É o que cria a concentração que a curva ABC mede.
        int[] pesos = new int[produtos.size()];
        for (int i = 0; i < pesos.length; i++) {
            pesos[i] = Math.max(1, produtos.size() - i * 2);
        }
        int somaPesos = 0;
        for (int p : pesos) {
            somaPesos += p;
        }

        try (BufferedWriter pedidosOut = new BufferedWriter(new FileWriter("pedidos.txt", true));
             BufferedWriter historicoOut = new BufferedWriter(new FileWriter("historico_vendas.txt", true))) {

            for (int dia = DIAS; dia >= 1; dia--) {
                LocalDate data = hoje.minusDays(dia);

                // tendência: começa devagar e cresce uns 60% ao longo do período
                double tendencia = 1.0 + 0.6 * (DIAS - dia) / (double) DIAS;
                // sazonalidade: sábado e domingo vendem bem menos
                double semana = switch (data.getDayOfWeek()) {
                    case SATURDAY -> 0.4;
                    case SUNDAY -> 0.2;
                    default -> 1.0;
                };

                int quantosHoje = (int) Math.round(
                        PEDIDOS_POR_DIA_BASE * tendencia * semana * (0.6 + sorteio.nextDouble() * 0.8));

                for (int i = 0; i < quantosHoje; i++) {
                    contador++;
                    Pessoa cliente = clientes.get(sorteio.nextInt(clientes.size()));
                    LocalDateTime momento = LocalDateTime.of(data,
                            LocalTime.of(8 + sorteio.nextInt(10), sorteio.nextInt(60)));

                    StringBuilder itens = new StringBuilder();
                    int quantosItens = 1 + sorteio.nextInt(3);
                    for (int j = 0; j < quantosItens; j++) {
                        Produto produto = sortearComPeso(produtos, pesos, somaPesos, sorteio);
                        int qtd = 1 + sorteio.nextInt(4);
                        if (itens.length() > 0) {
                            itens.append(';');
                        }
                        itens.append(produto.getId()).append(':').append(qtd).append(':')
                                .append(produto.getPreco().toPlainString());

                        historicoOut.write(produto.getId() + "," + qtd + "," + data);
                        historicoOut.newLine();
                    }

                    pedidosOut.write("H" + contador + "," + cliente.getId() + ","
                            + momento.format(java.time.format.DateTimeFormatter
                                    .ofPattern("yyyy-MM-dd HH:mm")) + "," + itens);
                    pedidosOut.newLine();
                }
            }
        }
        return contador;
    }

    private static Produto sortearComPeso(List<Produto> produtos, int[] pesos, int soma,
            Random sorteio) {
        int alvo = sorteio.nextInt(soma);
        int acumulado = 0;
        for (int i = 0; i < produtos.size(); i++) {
            acumulado += pesos[i];
            if (alvo < acumulado) {
                return produtos.get(i);
            }
        }
        return produtos.get(produtos.size() - 1);
    }

    private GeradorVendas() {
        // utilitária
    }
}
