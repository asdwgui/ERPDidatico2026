package com.erp;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

// DESAFIO 13 - componente 5: o painel gráfico.
//
// Três faixas, de cima para baixo:
//   1. os indicadores, em cartões
//   2. o gráfico de faturamento por dia, com a reta da previsão por cima
//   3. a curva ABC em tabela
//
// O gráfico é desenhado à mão com Java2D. Poderia ter entrado uma biblioteca de
// gráficos, e seria mais bonito - mas o Desafio 14 acabou de mostrar que cada
// dependência nova é uma superfície de ataque a acompanhar. Para um gráfico de
// linha, desenhar sai mais barato do que manter.
public class TelaPainelBI extends JFrame {

    private static final Color FUNDO = new Color(0xF7, 0xF8, 0xFA);
    private static final Color LINHA_REAL = new Color(0x1D, 0x5F, 0xA8);
    private static final Color LINHA_PREV = new Color(0xB8, 0x4A, 0x0F);
    private static final Color BOM = new Color(0x1F, 0x7A, 0x3F);
    private static final Color ATENCAO = new Color(0xA3, 0x34, 0x1C);

    private final ColetaBI.Dados dados;

    public TelaPainelBI(ColetaBI.Dados dados) {
        this.dados = dados;
        setTitle(Idioma.t("bi.tela.titulo"));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(980, 700);
        setLocationRelativeTo(null);
        getContentPane().setBackground(FUNDO);

        add(painelIndicadores(), BorderLayout.NORTH);
        add(new GraficoFaturamento(dados), BorderLayout.CENTER);
        add(painelABC(), BorderLayout.SOUTH);
    }

    // ---------------------------------------------------------------- cartões

    private JPanel painelIndicadores() {
        List<IndicadoresBI.Indicador> indicadores = IndicadoresBI.calcular(dados);
        JPanel grade = new JPanel(new GridLayout(2, 5, 8, 8));
        grade.setBorder(BorderFactory.createEmptyBorder(12, 12, 6, 12));
        grade.setBackground(FUNDO);

        for (IndicadoresBI.Indicador i : indicadores) {
            grade.add(cartao(Idioma.t(i.chave), i.valor, i.situacao));
        }
        return grade;
    }

    private JPanel cartao(String rotulo, String valor, String situacao) {
        JPanel cartao = new JPanel(new BorderLayout());
        cartao.setBackground(Color.WHITE);
        cartao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD9, 0xDE, 0xE4)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));

        JLabel texto = new JLabel(rotulo);
        texto.setFont(texto.getFont().deriveFont(Font.PLAIN, 10f));
        texto.setForeground(new Color(0x5B, 0x64, 0x70));

        JLabel numero = new JLabel(valor);
        numero.setFont(numero.getFont().deriveFont(Font.BOLD, 16f));
        if (situacao.equals("bom")) {
            numero.setForeground(BOM);
        } else if (situacao.equals("atencao")) {
            numero.setForeground(ATENCAO);
        }

        cartao.add(texto, BorderLayout.NORTH);
        cartao.add(numero, BorderLayout.CENTER);
        return cartao;
    }

    // ---------------------------------------------------------------- tabela ABC

    private JPanel painelABC() {
        List<CurvaABC.Linha> linhas = CurvaABC.calcular(dados);

        DefaultTableModel modelo = new DefaultTableModel(new String[] {
                Idioma.t("abc.col.classe"), Idioma.t("abc.col.produto"),
                Idioma.t("abc.col.faturamento"), Idioma.t("abc.col.parte"),
                Idioma.t("abc.col.acumulado") }, 0);

        for (CurvaABC.Linha l : linhas) {
            modelo.addRow(new Object[] { l.classe, l.nome, Formato.moeda(l.faturamento),
                    Formato.numero(l.participacao, 1) + "%",
                    Formato.numero(l.acumulado, 1) + "%" });
        }

        JTable tabela = new JTable(modelo);
        tabela.setAutoCreateRowSorter(true);
        tabela.setRowHeight(20);

        JScrollPane rolagem = new JScrollPane(tabela);
        rolagem.setPreferredSize(new Dimension(960, 190));

        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(FUNDO);
        painel.setBorder(BorderFactory.createEmptyBorder(6, 12, 12, 12));
        JLabel titulo = new JLabel(Idioma.t("abc.titulo"));
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 12f));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 4, 0));
        painel.add(titulo, BorderLayout.NORTH);
        painel.add(rolagem, BorderLayout.CENTER);
        return painel;
    }

    // ---------------------------------------------------------------- gráfico

    private static class GraficoFaturamento extends JPanel {
        private final ColetaBI.Dados dados;

        GraficoFaturamento(ColetaBI.Dados dados) {
            this.dados = dados;
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createEmptyBorder(6, 12, 6, 12),
                    BorderFactory.createLineBorder(new Color(0xD9, 0xDE, 0xE4))));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            int margemEsq = 70;
            int margemDir = 20;
            int margemCima = 30;
            int margemBaixo = 36;
            int largura = getWidth() - margemEsq - margemDir;
            int altura = getHeight() - margemCima - margemBaixo;

            g2.setFont(g2.getFont().deriveFont(11f));
            g2.setColor(new Color(0x1F, 0x23, 0x28));
            g2.drawString(Idioma.t("bi.grafico.titulo"), margemEsq, 18);

            if (dados.porDia.isEmpty() || largura <= 0 || altura <= 0) {
                g2.setColor(new Color(0x5B, 0x64, 0x70));
                g2.drawString(Idioma.t("bi.sem.dados"), margemEsq, margemCima + 20);
                return;
            }

            LocalDate primeiro = dados.porDia.firstKey();
            LocalDate ultimo = dados.porDia.lastKey();
            long diasHistorico = java.time.temporal.ChronoUnit.DAYS.between(primeiro, ultimo);
            int diasFuturos = 30;
            long diasTotais = Math.max(1, diasHistorico + diasFuturos);

            double maximo = 0;
            for (BigDecimal v : dados.porDia.values()) {
                maximo = Math.max(maximo, v.doubleValue());
            }
            List<double[]> previsao = PrevisaoBI.pontosDaReta(dados, diasFuturos);
            for (double[] p : previsao) {
                maximo = Math.max(maximo, p[1]);
            }
            if (maximo <= 0) {
                maximo = 1;
            }

            // eixos e três linhas de grade
            g2.setColor(new Color(0xE6, 0xE9, 0xED));
            for (int i = 0; i <= 3; i++) {
                int y = margemCima + altura - (int) (altura * i / 3.0);
                g2.drawLine(margemEsq, y, margemEsq + largura, y);
                g2.setColor(new Color(0x8A, 0x92, 0x9C));
                g2.drawString(Formato.moeda(BigDecimal.valueOf(maximo * i / 3.0)), 4, y + 4);
                g2.setColor(new Color(0xE6, 0xE9, 0xED));
            }

            // a linha da previsão primeiro, para ficar atrás do histórico
            g2.setColor(LINHA_PREV);
            g2.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                    1f, new float[] { 5f, 4f }, 0f));
            int xAnterior = -1;
            int yAnterior = -1;
            for (double[] p : previsao) {
                int x = margemEsq + (int) (largura * p[0] / diasTotais);
                int y = margemCima + altura - (int) (altura * p[1] / maximo);
                if (xAnterior >= 0) {
                    g2.drawLine(xAnterior, yAnterior, x, y);
                }
                xAnterior = x;
                yAnterior = y;
            }

            // o histórico por cima
            g2.setColor(LINHA_REAL);
            g2.setStroke(new BasicStroke(1.8f));
            xAnterior = -1;
            yAnterior = -1;
            for (Map.Entry<LocalDate, BigDecimal> e : dados.porDia.entrySet()) {
                long dia = java.time.temporal.ChronoUnit.DAYS.between(primeiro, e.getKey());
                int x = margemEsq + (int) (largura * dia / diasTotais);
                int y = margemCima + altura - (int) (altura * e.getValue().doubleValue() / maximo);
                if (xAnterior >= 0) {
                    g2.drawLine(xAnterior, yAnterior, x, y);
                }
                xAnterior = x;
                yAnterior = y;
            }

            // a marca de onde o histórico acaba e a projeção começa
            int xCorte = margemEsq + (int) (largura * diasHistorico / diasTotais);
            g2.setColor(new Color(0x8A, 0x92, 0x9C));
            g2.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER,
                    1f, new float[] { 3f, 3f }, 0f));
            g2.drawLine(xCorte, margemCima, xCorte, margemCima + altura);

            g2.setStroke(new BasicStroke(1f));
            g2.setColor(new Color(0x5B, 0x64, 0x70));
            g2.drawString(primeiro.toString(), margemEsq, getHeight() - 14);
            g2.drawString(ultimo.toString(), xCorte - 30, getHeight() - 14);

            // legenda
            g2.setColor(LINHA_REAL);
            g2.fillRect(margemEsq + largura - 170, getHeight() - 22, 14, 3);
            g2.setColor(new Color(0x1F, 0x23, 0x28));
            g2.drawString(Idioma.t("bi.grafico.real"), margemEsq + largura - 150, getHeight() - 16);
            g2.setColor(LINHA_PREV);
            g2.fillRect(margemEsq + largura - 80, getHeight() - 22, 14, 3);
            g2.setColor(new Color(0x1F, 0x23, 0x28));
            g2.drawString(Idioma.t("bi.grafico.previsto"), margemEsq + largura - 60,
                    getHeight() - 16);
        }
    }

    // ---------------------------------------------------------------- abertura

    public static void abrir() throws IOException {
        ColetaBI.Dados dados = ColetaBI.obter();
        javax.swing.SwingUtilities.invokeLater(() -> new TelaPainelBI(dados).setVisible(true));
    }

}
