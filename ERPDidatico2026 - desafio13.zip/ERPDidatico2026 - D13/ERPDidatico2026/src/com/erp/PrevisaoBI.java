package com.erp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

// DESAFIO 13 - componente 4: a parte "preditiva" do painel.
//
// O Desafio 3 já tinha uma previsão, mas ela respondia "quantas unidades deste
// produto vou vender amanhã?". Aqui a pergunta é outra: "QUANTO A EMPRESA VAI
// FATURAR NO PRÓXIMO MÊS?" - que é o que vai para a reunião de diretoria.
//
// Muda o que se mede (dinheiro, não unidade), muda o alcance (a empresa toda,
// não um item) e muda o horizonte (trinta dias, não um).
//
// O método é o mesmo: regressão linear. Traça a reta que melhor acompanha o
// histórico e estende para frente. É simples de propósito - dá para explicar o
// resultado em uma frase, e um número que ninguém sabe explicar não é usado
// para decidir nada.
public class PrevisaoBI {

    private static final int DIAS_PREVISTOS = 30;
    // Abaixo disso a reta é chute: duas semanas de dados não dizem nada sobre
    // o mês que vem.
    private static final int MINIMO_DE_DIAS = 14;

    public static class Resultado {
        public final boolean possivel;
        public final BigDecimal previstoProximoMes;
        public final BigDecimal mediaDiariaAtual;
        public final BigDecimal mediaDiariaPrevista;
        public final double variacaoPercentual;
        public final int diasDeHistorico;
        public final double inclinacao; // reais por dia de crescimento

        Resultado(boolean possivel, BigDecimal previsto, BigDecimal atual,
                BigDecimal prevista, double variacao, int dias, double inclinacao) {
            this.possivel = possivel;
            this.previstoProximoMes = previsto;
            this.mediaDiariaAtual = atual;
            this.mediaDiariaPrevista = prevista;
            this.variacaoPercentual = variacao;
            this.diasDeHistorico = dias;
            this.inclinacao = inclinacao;
        }
    }

    public static Resultado calcular(ColetaBI.Dados d) {
        if (d.porDia.size() < MINIMO_DE_DIAS) {
            return new Resultado(false, BigDecimal.ZERO, BigDecimal.ZERO,
                    BigDecimal.ZERO, 0, d.porDia.size(), 0);
        }

        LocalDate primeiro = d.porDia.firstKey();
        LocalDate ultimo = d.porDia.lastKey();

        // Dias sem venda entram como zero. Se ficassem de fora, a reta
        // acompanharia só os dias bons e a previsão sairia otimista demais -
        // foi exatamente a correção feita na previsão do Desafio 3.
        List<Double> xs = new ArrayList<>();
        List<Double> ys = new ArrayList<>();
        for (LocalDate dia = primeiro; !dia.isAfter(ultimo); dia = dia.plusDays(1)) {
            xs.add((double) ChronoUnit.DAYS.between(primeiro, dia));
            ys.add(d.porDia.getOrDefault(dia, BigDecimal.ZERO).doubleValue());
        }

        double[] reta = regressao(xs, ys);
        double inclinacao = reta[0];
        double intercepto = reta[1];

        long diasTotais = ChronoUnit.DAYS.between(primeiro, ultimo) + 1;

        double somaPrevista = 0;
        for (int i = 1; i <= DIAS_PREVISTOS; i++) {
            // Faturamento negativo não existe: a reta pode apontar para baixo,
            // mas o chão é zero.
            somaPrevista += Math.max(0, inclinacao * (diasTotais + i) + intercepto);
        }

        double mediaAtual = d.faturamento.doubleValue() / diasTotais;
        double mediaPrevista = somaPrevista / DIAS_PREVISTOS;
        double variacao = (mediaAtual == 0) ? 0 : (mediaPrevista - mediaAtual) / mediaAtual * 100;

        return new Resultado(true,
                BigDecimal.valueOf(somaPrevista).setScale(2, java.math.RoundingMode.HALF_UP),
                BigDecimal.valueOf(mediaAtual).setScale(2, java.math.RoundingMode.HALF_UP),
                BigDecimal.valueOf(mediaPrevista).setScale(2, java.math.RoundingMode.HALF_UP),
                variacao, (int) diasTotais, inclinacao);
    }

    private static double[] regressao(List<Double> xs, List<Double> ys) {
        int n = xs.size();
        if (n < 2) {
            return new double[] { 0, 0 };
        }
        double somaX = 0;
        double somaY = 0;
        double somaXY = 0;
        double somaX2 = 0;
        for (int i = 0; i < n; i++) {
            somaX += xs.get(i);
            somaY += ys.get(i);
            somaXY += xs.get(i) * ys.get(i);
            somaX2 += xs.get(i) * xs.get(i);
        }
        double denominador = n * somaX2 - somaX * somaX;
        if (Math.abs(denominador) < 1e-10) {
            return new double[] { 0, somaY / n };
        }
        double m = (n * somaXY - somaX * somaY) / denominador;
        return new double[] { m, (somaY - m * somaX) / n };
    }

    // Os pontos da reta, para a tela desenhar junto com o histórico.
    public static List<double[]> pontosDaReta(ColetaBI.Dados d, int diasAFrente) {
        List<double[]> pontos = new ArrayList<>();
        if (d.porDia.size() < 2) {
            return pontos;
        }
        LocalDate primeiro = d.porDia.firstKey();
        LocalDate ultimo = d.porDia.lastKey();

        List<Double> xs = new ArrayList<>();
        List<Double> ys = new ArrayList<>();
        for (Map.Entry<LocalDate, BigDecimal> e : d.porDia.entrySet()) {
            xs.add((double) ChronoUnit.DAYS.between(primeiro, e.getKey()));
            ys.add(e.getValue().doubleValue());
        }
        double[] reta = regressao(xs, ys);

        long total = ChronoUnit.DAYS.between(primeiro, ultimo) + diasAFrente;
        for (long i = 0; i <= total; i++) {
            pontos.add(new double[] { i, Math.max(0, reta[0] * i + reta[1]) });
        }
        return pontos;
    }

    // ---------------------------------------------------------------- console

    public static void imprimir(ColetaBI.Dados d) {
        Resultado r = calcular(d);

        System.out.println();
        System.out.println(Idioma.t("prev.titulo"));
        Console.linha();

        if (!r.possivel) {
            Console.aviso(Idioma.t("prev.sem.historico", MINIMO_DE_DIAS, r.diasDeHistorico));
            return;
        }

        System.out.printf("%-34s %18s%n", Idioma.t("prev.historico"),
                r.diasDeHistorico + " " + Idioma.t("prev.dias"));
        System.out.printf("%-34s %18s%n", Idioma.t("prev.media.atual"),
                Formato.moeda(r.mediaDiariaAtual));
        System.out.printf("%-34s %18s%n", Idioma.t("prev.media.prevista"),
                Formato.moeda(r.mediaDiariaPrevista));
        System.out.printf("%-34s %18s%n", Idioma.t("prev.total"),
                Formato.moeda(r.previstoProximoMes));
        Console.linha();

        if (r.variacaoPercentual > 5) {
            Console.ok(Idioma.t("prev.subindo", Formato.numero(r.variacaoPercentual, 1)));
        } else if (r.variacaoPercentual < -5) {
            Console.aviso(Idioma.t("prev.caindo", Formato.numero(-r.variacaoPercentual, 1)));
        } else {
            System.out.println("   " + Idioma.t("prev.estavel"));
        }

        // O aviso que separa um painel honesto de um que vende ilusão.
        System.out.println();
        System.out.println("   " + Idioma.t("prev.ressalva"));
    }
}
