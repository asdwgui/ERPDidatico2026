package com.erp;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

// DESAFIO 13 - componente 1: coleta e cache.
//
// Esta é a peça que responde à exigência do enunciado de "garantir a
// escalabilidade da solução SEM COMPROMETER os módulos existentes".
//
// O PROBLEMA. Um painel de BI lê tudo: todos os pedidos, todos os produtos,
// todos os títulos. Se ele refizesse essa leitura a cada vez que alguém abre a
// tela, o ERP ficaria lento na mesma medida em que a empresa cresce - exatamente
// o defeito que o Desafio 10 encontrou e corrigiu nas vendas. Seria estranho
// consertar lá e reintroduzir aqui.
//
// A SOLUÇÃO. O painel lê os arquivos UMA vez e guarda o resultado. Nas próximas
// aberturas ele devolve o que já tem. E para não mostrar número velho, confere
// a data de modificação dos arquivos: se algum mudou, recalcula.
//
// Isso é melhor do que o cache do Desafio 10, e vale explicar a diferença. Lá o
// cache depende de alguém lembrar de marcar "o estoque mudou" toda vez que mexe
// num produto - se alguém esquecer uma linha, o relatório mente. Aqui o cache
// pergunta ao sistema de arquivos. Não existe o que esquecer.
public class ColetaBI {

    private static final String[] ARQUIVOS = {
            "pedidos.txt", "produtos.txt", "titulos.txt" };

    // ---------------------------------------------------------------- o que foi coletado

    public static class Dados {
        public BigDecimal faturamento = BigDecimal.ZERO;
        public int quantidadePedidos = 0;
        public int itensVendidos = 0;
        public BigDecimal valorEmEstoque = BigDecimal.ZERO;
        public int produtosCadastrados = 0;
        public int produtosZerados = 0;
        public BigDecimal aReceber = BigDecimal.ZERO;
        public BigDecimal aPagar = BigDecimal.ZERO;

        // Faturamento dia a dia, em ordem de data. Alimenta o gráfico e a previsão.
        public final TreeMap<LocalDate, BigDecimal> porDia = new TreeMap<>();
        // Faturamento por produto. Alimenta a curva ABC.
        public final Map<String, BigDecimal> porProduto = new LinkedHashMap<>();
        // Nome de cada produto, para o relatório não mostrar só o ID.
        public final Map<String, String> nomes = new LinkedHashMap<>();

    }

    // DEFEITO ENCONTRADO PELO TESTE, e vale registrar porque a causa é sutil.
    //
    // Estes dois campos moravam dentro de Dados. Como o cache devolve SEMPRE o
    // mesmo objeto, a segunda chamada marcava "veio do cache" no objeto que a
    // primeira chamada já tinha devolvido - e quem guardou a referência da
    // primeira via o valor mudar sozinho. O número do painel nunca ficou errado,
    // mas a informação sobre a origem do dado, sim.
    //
    // A correção é conceitual: "veio do cache" não é propriedade do DADO, é
    // propriedade da CHAMADA. Então saiu de Dados e virou estado da classe.
    private static boolean ultimoVeioDoCache = false;
    private static double ultimoMs = 0;

    public static boolean ultimaLeituraVeioDoCache() {
        return ultimoVeioDoCache;
    }

    public static double msDaUltimaLeitura() {
        return ultimoMs;
    }

    private static Dados cache = null;
    private static long assinaturaDoCache = -1;

    // ---------------------------------------------------------------- entrada

    public static Dados obter() throws IOException {
        long assinatura = assinaturaDosArquivos();

        if (cache != null && assinatura == assinaturaDoCache) {
            ultimoVeioDoCache = true;
            ultimoMs = 0;
            return cache;
        }

        long inicio = System.nanoTime();
        Dados dados = calcular();
        ultimoMs = (System.nanoTime() - inicio) / 1_000_000.0;
        ultimoVeioDoCache = false;

        cache = dados;
        assinaturaDoCache = assinatura;
        return dados;
    }

    // Soma das datas de modificação. Se qualquer arquivo mudar, a soma muda.
    // É barato: não lê o conteúdo, só pergunta ao sistema de arquivos.
    private static long assinaturaDosArquivos() {
        long soma = 0;
        for (String nome : ARQUIVOS) {
            File arquivo = new File(nome);
            soma = soma * 31 + (arquivo.exists() ? arquivo.lastModified() + arquivo.length() : 0);
        }
        return soma;
    }

    public static void invalidar() {
        cache = null;
        assinaturaDoCache = -1;
    }

    // ---------------------------------------------------------------- cálculo

    private static Dados calcular() throws IOException {
        Dados d = new Dados();
        lerProdutos(d);
        lerPedidos(d);
        lerTitulos(d);
        return d;
    }

    private static void lerProdutos(Dados d) throws IOException {
        for (String linha : linhasDe("produtos.txt")) {
            String[] p = linha.split(",");
            if (p.length < 4) {
                continue;
            }
            try {
                BigDecimal preco = new BigDecimal(p[2].trim());
                int qtd = Integer.parseInt(p[3].trim());
                d.produtosCadastrados++;
                d.valorEmEstoque = d.valorEmEstoque.add(preco.multiply(BigDecimal.valueOf(qtd)));
                if (qtd == 0) {
                    d.produtosZerados++;
                }
                d.nomes.put(p[0], p[1]);
            } catch (NumberFormatException e) {
                // linha corrompida não derruba o painel inteiro
            }
        }
    }

    private static void lerPedidos(Dados d) throws IOException {
        for (String linha : linhasDe("pedidos.txt")) {
            String[] p = linha.split(",");
            if (p.length < 4) {
                continue;
            }
            LocalDate data = Formato.dataDoArquivo(p[2]);
            BigDecimal totalDoPedido = BigDecimal.ZERO;

            for (String itemTexto : p[3].split(";")) {
                String[] i = itemTexto.split(":");
                if (i.length < 3) {
                    continue;
                }
                try {
                    int qtd = Integer.parseInt(i[1].trim());
                    BigDecimal subtotal = new BigDecimal(i[2].trim())
                            .multiply(BigDecimal.valueOf(qtd));
                    totalDoPedido = totalDoPedido.add(subtotal);
                    d.itensVendidos += qtd;
                    d.porProduto.merge(i[0], subtotal, BigDecimal::add);
                } catch (NumberFormatException e) {
                    // idem
                }
            }

            d.quantidadePedidos++;
            d.faturamento = d.faturamento.add(totalDoPedido);
            if (data != null) {
                d.porDia.merge(data, totalDoPedido, BigDecimal::add);
            }
        }
    }

    private static void lerTitulos(Dados d) throws IOException {
        for (String linha : linhasDe("titulos.txt")) {
            String[] p = linha.split(",");
            if (p.length < 5) {
                continue;
            }
            boolean pago = Boolean.parseBoolean(p[2].trim());
            if (pago) {
                continue;
            }
            try {
                BigDecimal valor = new BigDecimal(p[1].trim());
                if (p[4].trim().equalsIgnoreCase("a receber")) {
                    d.aReceber = d.aReceber.add(valor);
                } else {
                    d.aPagar = d.aPagar.add(valor);
                }
            } catch (NumberFormatException e) {
                // idem
            }
        }
    }

    private static Iterable<String> linhasDe(String arquivo) throws IOException {
        Path caminho = Path.of(arquivo);
        if (!Files.exists(caminho)) {
            return java.util.List.of();
        }
        return Files.readAllLines(caminho, StandardCharsets.UTF_8).stream()
                .filter(l -> !l.isBlank() && !l.startsWith("#")).toList();
    }
}
