package com.erp;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

// DESAFIO 13 - componente 3: a curva ABC.
//
// É a "análise de desempenho" que o enunciado pede, e a pergunta que ela
// responde é: QUAIS PRODUTOS REALMENTE IMPORTAM?
//
// A ideia vem de Pareto: na maioria dos negócios, uma minoria dos produtos
// responde pela maior parte do faturamento. A curva ABC ordena tudo do que mais
// vende para o que menos vende e corta em três faixas:
//
//   A - os produtos que somam os primeiros 80% do faturamento
//   B - os que somam os 15% seguintes
//   C - o resto, que soma os últimos 5%
//
// Para que serve na prática: os produtos A nunca podem faltar e merecem
// negociação com o fornecedor. Os C ocupam prateleira, dão trabalho de cadastro
// e quase não trazem receita - são candidatos a sair do catálogo.
//
// Repare que a classificação NÃO é por quantidade vendida, e sim por
// faturamento. Um produto barato vendido aos montes pode ser C; um caro vendido
// poucas vezes pode ser A. É o dinheiro que decide.
public class CurvaABC {

    private static final double CORTE_A = 0.80;
    private static final double CORTE_B = 0.95;

    public static class Linha {
        public final String produtoId;
        public final String nome;
        public final BigDecimal faturamento;
        public final double participacao;      // quanto este produto representa
        public final double acumulado;         // quanto ele e os anteriores somam
        public final String classe;            // "A", "B" ou "C"

        Linha(String produtoId, String nome, BigDecimal faturamento,
                double participacao, double acumulado, String classe) {
            this.produtoId = produtoId;
            this.nome = nome;
            this.faturamento = faturamento;
            this.participacao = participacao;
            this.acumulado = acumulado;
            this.classe = classe;
        }
    }

    public static List<Linha> calcular(ColetaBI.Dados d) {
        List<Map.Entry<String, BigDecimal>> ordenados = new ArrayList<>(d.porProduto.entrySet());
        ordenados.sort(Comparator.comparing(Map.Entry<String, BigDecimal>::getValue).reversed());

        BigDecimal total = BigDecimal.ZERO;
        for (Map.Entry<String, BigDecimal> e : ordenados) {
            total = total.add(e.getValue());
        }

        List<Linha> linhas = new ArrayList<>();
        if (total.signum() == 0) {
            return linhas;
        }

        double acumulado = 0;
        for (Map.Entry<String, BigDecimal> e : ordenados) {
            double participacao = e.getValue().doubleValue() / total.doubleValue();
            // A classe é definida pelo acumulado ANTES de somar este produto.
            // Assim o produto que cruza a linha dos 80% ainda é A - ele faz parte
            // do grupo que chegou até lá.
            String classe = (acumulado < CORTE_A) ? "A" : (acumulado < CORTE_B) ? "B" : "C";
            acumulado += participacao;
            linhas.add(new Linha(e.getKey(), d.nomes.getOrDefault(e.getKey(), e.getKey()),
                    e.getValue(), participacao * 100, acumulado * 100, classe));
        }
        return linhas;
    }

    // Quantos produtos e quanto de faturamento em cada classe.
    public static Map<String, int[]> resumo(List<Linha> linhas) {
        Map<String, int[]> contagem = new java.util.LinkedHashMap<>();
        contagem.put("A", new int[] { 0, 0 });
        contagem.put("B", new int[] { 0, 0 });
        contagem.put("C", new int[] { 0, 0 });
        for (Linha l : linhas) {
            int[] v = contagem.get(l.classe);
            v[0]++;
            v[1] += (int) Math.round(l.participacao * 100); // décimos de ponto percentual
        }
        return contagem;
    }

    // ---------------------------------------------------------------- console

    public static void imprimir(ColetaBI.Dados d) {
        List<Linha> linhas = calcular(d);
        if (linhas.isEmpty()) {
            return;
        }

        System.out.println();
        System.out.println(Idioma.t("abc.titulo"));
        Console.linha();
        System.out.printf("%-3s %-8s %-30s %14s %8s %9s%n",
                Idioma.t("abc.col.classe"), Idioma.t("abc.col.id"), Idioma.t("abc.col.produto"),
                Idioma.t("abc.col.faturamento"), Idioma.t("abc.col.parte"),
                Idioma.t("abc.col.acumulado"));
        Console.linha();

        // Mostra os produtos A e B inteiros, e resume os C. Listar 50 produtos
        // que juntos valem 5% do faturamento é o tipo de tabela que ninguém lê.
        int cOcultos = 0;
        for (Linha l : linhas) {
            if (l.classe.equals("C")) {
                cOcultos++;
                continue;
            }
            System.out.printf("%-3s %-8s %-30s %14s %7s%% %8s%%%n", l.classe, l.produtoId,
                    cortar(l.nome, 30), Formato.moeda(l.faturamento),
                    Formato.numero(l.participacao, 1), Formato.numero(l.acumulado, 1));
        }
        if (cOcultos > 0) {
            System.out.printf("%-3s %s%n", "C", Idioma.t("abc.ocultos", cOcultos));
        }
        Console.linha();

        Map<String, int[]> resumo = resumo(linhas);
        for (Map.Entry<String, int[]> e : resumo.entrySet()) {
            if (e.getValue()[0] == 0) {
                continue;
            }
            System.out.printf("   %s: %s%n", e.getKey(),
                    Idioma.t("abc.resumo", e.getValue()[0],
                            Formato.numero(e.getValue()[1] / 100.0, 1)));
        }

        // A frase que transforma a tabela em decisão.
        int quantosA = resumo.get("A")[0];
        if (quantosA > 0 && !linhas.isEmpty()) {
            System.out.println();
            Console.aviso(Idioma.t("abc.conclusao", quantosA, linhas.size(),
                    Formato.numero(resumo.get("A")[1] / 100.0, 0)));
        }
    }

    private static String cortar(String texto, int tamanho) {
        if (texto == null) {
            return "";
        }
        return texto.length() <= tamanho ? texto : texto.substring(0, tamanho - 1) + "…";
    }
}
