package com.erp;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public class TestePainelBI {

    private static int passou = 0;
    private static int falhou = 0;

    public static void main(String[] args) throws IOException {
        Console.linha();
        System.out.println("TESTE DO PAINEL DE BI");
        Console.linha();

        ColetaBI.invalidar();
        ColetaBI.Dados d = ColetaBI.obter();

        if (d.quantidadePedidos == 0) {
            Console.aviso("Nenhum pedido na base. Rode o GeradorVendas antes.");
            return;
        }

        testarCoerencia(d);
        testarCurvaABC(d);
        testarPrevisao(d);
        testarCache();

        Console.linha();
        System.out.printf("%d conferências, %d de acordo, %d FORA DO ESPERADO%n",
                passou + falhou, passou, falhou);
        if (falhou == 0) {
            System.out.println("Os números do painel fecham e o cache está funcionando.");
        } else {
            System.out.println("ATENÇÃO: o painel está mostrando número que não fecha.");
        }
        Console.linha();
    }

    private static void testarCoerencia(ColetaBI.Dados d) {
        titulo("OS NÚMEROS FECHAM?");

        System.out.printf("   %-40s %s%n", "pedidos lidos", d.quantidadePedidos);
        System.out.printf("   %-40s %s%n", "faturamento total", Formato.moeda(d.faturamento));
        System.out.printf("   %-40s %s%n", "dias com venda", d.porDia.size());
        System.out.printf("   %-40s %s%n", "produtos vendidos", d.porProduto.size());

        BigDecimal somaDias = BigDecimal.ZERO;
        for (BigDecimal v : d.porDia.values()) {
            somaDias = somaDias.add(v);
        }
        conferir("a soma dos dias bate com o faturamento total",
                d.faturamento.compareTo(somaDias) == 0,
                Formato.moeda(somaDias));

        BigDecimal somaProdutos = BigDecimal.ZERO;
        for (BigDecimal v : d.porProduto.values()) {
            somaProdutos = somaProdutos.add(v);
        }
        conferir("a soma dos produtos bate com o faturamento total",
                d.faturamento.compareTo(somaProdutos) == 0,
                Formato.moeda(somaProdutos));

        conferir("nenhum dia com faturamento negativo",
                d.porDia.values().stream().noneMatch(v -> v.signum() < 0), "ok");
        conferir("todo produto vendido tem nome conhecido",
                d.porProduto.keySet().stream().allMatch(d.nomes::containsKey), "ok");
    }

    private static void testarCurvaABC(ColetaBI.Dados d) {
        titulo("CURVA ABC");

        List<CurvaABC.Linha> linhas = CurvaABC.calcular(d);
        conferir("a curva tem uma linha por produto vendido",
                linhas.size() == d.porProduto.size(), String.valueOf(linhas.size()));

        double ultimoAcumulado = linhas.isEmpty() ? 0 : linhas.get(linhas.size() - 1).acumulado;
        conferir("o acumulado da última linha chega a 100%",
                Math.abs(ultimoAcumulado - 100) < 0.01,
                Formato.numero(ultimoAcumulado, 2) + "%");

        boolean ordenada = true;
        for (int i = 1; i < linhas.size(); i++) {
            if (linhas.get(i - 1).faturamento.compareTo(linhas.get(i).faturamento) < 0) {
                ordenada = false;
                break;
            }
        }
        conferir("a curva está ordenada do maior para o menor", ordenada, "ok");

        boolean classesEmOrdem = true;
        String anterior = "A";
        for (CurvaABC.Linha l : linhas) {
            if (l.classe.compareTo(anterior) < 0) {
                classesEmOrdem = false;
                break;
            }
            anterior = l.classe;
        }
        conferir("as classes aparecem na ordem A, B, C", classesEmOrdem, "ok");

        var resumo = CurvaABC.resumo(linhas);
        System.out.printf("   %-40s A=%d  B=%d  C=%d%n", "produtos por classe",
                resumo.get("A")[0], resumo.get("B")[0], resumo.get("C")[0]);
    }

    private static void testarPrevisao(ColetaBI.Dados d) {
        titulo("PREVISÃO");

        PrevisaoBI.Resultado r = PrevisaoBI.calcular(d);
        if (!r.possivel) {
            Console.aviso("Histórico curto demais para prever. Precisa de pelo menos 14 dias.");
            return;
        }

        System.out.printf("   %-40s %s%n", "média diária atual",
                Formato.moeda(r.mediaDiariaAtual));
        System.out.printf("   %-40s %s%n", "média diária projetada",
                Formato.moeda(r.mediaDiariaPrevista));
        System.out.printf("   %-40s %s%n", "projeção para 30 dias",
                Formato.moeda(r.previstoProximoMes));

        conferir("a projeção não é negativa", r.previstoProximoMes.signum() >= 0, "ok");

        conferir("a previsão encontrou a tendência de alta da base",
                r.inclinacao > 0, Formato.numero(r.inclinacao, 2) + " por dia");

        conferir("a projeção de 30 dias é coerente com a média projetada",
                Math.abs(r.previstoProximoMes.doubleValue()
                        - r.mediaDiariaPrevista.doubleValue() * 30) < 1.0, "ok");
    }

    private static void testarCache() throws IOException {
        titulo("CACHE - a exigência de não comprometer os módulos existentes");

        ColetaBI.invalidar();
        long inicio = System.nanoTime();
        ColetaBI.Dados primeira = ColetaBI.obter();
        boolean primeiraVeioDoCache = ColetaBI.ultimaLeituraVeioDoCache();
        double msPrimeira = (System.nanoTime() - inicio) / 1_000_000.0;

        inicio = System.nanoTime();
        ColetaBI.Dados segunda = ColetaBI.obter();
        boolean segundaVeioDoCache = ColetaBI.ultimaLeituraVeioDoCache();
        double msSegunda = (System.nanoTime() - inicio) / 1_000_000.0;

        System.out.printf("   %-40s %s ms%n", "1ª abertura (lê os arquivos)",
                Formato.numero(msPrimeira, 2));
        System.out.printf("   %-40s %s ms%n", "2ª abertura (usa o cache)",
                Formato.numero(msSegunda, 2));
        if (msSegunda > 0) {
            System.out.printf("   %-40s %s x%n", "diferença",
                    Formato.numero(msPrimeira / msSegunda, 0));
        }

        conferir("a primeira abertura calculou", !primeiraVeioDoCache,
                primeiraVeioDoCache ? "veio do cache" : "calculou");
        conferir("a segunda abertura veio do cache", segundaVeioDoCache,
                segundaVeioDoCache ? "cache" : "recalculou");
        conferir("o cache devolve exatamente os mesmos números",
                primeira.faturamento.compareTo(segunda.faturamento) == 0
                        && primeira.quantidadePedidos == segunda.quantidadePedidos, "ok");
        conferir("a segunda abertura é mais rápida que a primeira",
                msSegunda < msPrimeira, "ok");
    }

    private static void titulo(String texto) {
        System.out.println();
        System.out.println(">>> " + texto);
        Console.linha();
    }

    private static void conferir(String caso, boolean bateu, String observado) {
        if (bateu) {
            passou++;
        } else {
            falhou++;
        }
        System.out.printf("  %-5s %-52s %s%n", bateu ? "[ok]" : "[!!]", caso, observado);
    }
}
