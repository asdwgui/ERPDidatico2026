package com.erp;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class ColetaBI {

    private static final String[] ARQUIVOS = {
            "pedidos.txt", "produtos.txt", "titulos.txt" };

    public static class Dados {
        public BigDecimal faturamento = BigDecimal.ZERO;
        public int quantidadePedidos = 0;
        public int itensVendidos = 0;
        public BigDecimal valorEmEstoque = BigDecimal.ZERO;
        public int produtosCadastrados = 0;
        public int produtosZerados = 0;
        public BigDecimal aReceber = BigDecimal.ZERO;
        public BigDecimal aPagar = BigDecimal.ZERO;
        public final TreeMap<LocalDate, BigDecimal> porDia = new TreeMap<>();
        public final Map<String, BigDecimal> porProduto = new LinkedHashMap<>();
        public final Map<String, String> nomes = new LinkedHashMap<>();

    }

    private static boolean ultimoVeioDoCache = false;
    private static double ultimoMs = 0;

    public static boolean ultimaLeituraVeioDoCache() {
        return ultimoVeioDoCache;
    }

    public static double msDaUltimaLeitura() {
        return ultimoMs;
    }

    private static Dados cache = null;
    private static long assinaturaDoCache = -1;

    public static Dados obter() throws IOException {
        long assinatura = assinaturaDosArquivos();

        if (cache != null && assinatura == assinaturaDoCache) {
            ultimoVeioDoCache = true;
            ultimoMs = 0;
            return cache;
        }

        long inicio = System.nanoTime();
        Dados dados = calcular();
        ultimoMs = (System.nanoTime() - inicio) / 1_000_000.0;
        ultimoVeioDoCache = false;

        cache = dados;
        assinaturaDoCache = assinatura;
        return dados;
    }

    private static long assinaturaDosArquivos() {
        long soma = 0;
        for (String nome : ARQUIVOS) {
            File arquivo = new File(nome);
            soma = soma * 31 + (arquivo.exists() ? arquivo.lastModified() + arquivo.length() : 0);
        }
        return soma;
    }

    public static void invalidar() {
        cache = null;
        assinaturaDoCache = -1;
    }

    private static Dados calcular() throws IOException {
        Dados d = new Dados();
        lerProdutos(d);
        lerPedidos(d);
        lerTitulos(d);
        return d;
    }

    private static void lerProdutos(Dados d) throws IOException {
        for (String linha : linhasDe("produtos.txt")) {
            String[] p = linha.split(",");
            if (p.length < 4) {
                continue;
            }
            try {
                BigDecimal preco = new BigDecimal(p[2].trim());
                int qtd = Integer.parseInt(p[3].trim());
                d.produtosCadastrados++;
                d.valorEmEstoque = d.valorEmEstoque.add(preco.multiply(BigDecimal.valueOf(qtd)));
                if (qtd == 0) {
                    d.produtosZerados++;
                }
                d.nomes.put(p[0], p[1]);
            } catch (NumberFormatException e) {
            }
        }
    }

    private static void lerPedidos(Dados d) throws IOException {
        for (String linha : linhasDe("pedidos.txt")) {
            String[] p = linha.split(",");
            if (p.length < 4) {
                continue;
            }
            LocalDate data = Formato.dataDoArquivo(p[2]);
            BigDecimal totalDoPedido = BigDecimal.ZERO;

            for (String itemTexto : p[3].split(";")) {
                String[] i = itemTexto.split(":");
                if (i.length < 3) {
                    continue;
                }
                try {
                    int qtd = Integer.parseInt(i[1].trim());
                    BigDecimal subtotal = new BigDecimal(i[2].trim())
                            .multiply(BigDecimal.valueOf(qtd));
                    totalDoPedido = totalDoPedido.add(subtotal);
                    d.itensVendidos += qtd;
                    d.porProduto.merge(i[0], subtotal, BigDecimal::add);
                } catch (NumberFormatException e) {
                }
            }

            d.quantidadePedidos++;
            d.faturamento = d.faturamento.add(totalDoPedido);
            if (data != null) {
                d.porDia.merge(data, totalDoPedido, BigDecimal::add);
            }
        }
    }

    private static void lerTitulos(Dados d) throws IOException {
        for (String linha : linhasDe("titulos.txt")) {
            String[] p = linha.split(",");
            if (p.length < 5) {
                continue;
            }
            boolean pago = Boolean.parseBoolean(p[2].trim());
            if (pago) {
                continue;
            }
            try {
                BigDecimal valor = new BigDecimal(p[1].trim());
                if (p[4].trim().equalsIgnoreCase("a receber")) {
                    d.aReceber = d.aReceber.add(valor);
                } else {
                    d.aPagar = d.aPagar.add(valor);
                }
            } catch (NumberFormatException e) {
            }
        }
    }

    private static Iterable<String> linhasDe(String arquivo) throws IOException {
        Path caminho = Path.of(arquivo);
        if (!Files.exists(caminho)) {
            return java.util.List.of();
        }
        return Files.readAllLines(caminho, StandardCharsets.UTF_8).stream()
                .filter(l -> !l.isBlank() && !l.startsWith("#")).toList();
    }
}
