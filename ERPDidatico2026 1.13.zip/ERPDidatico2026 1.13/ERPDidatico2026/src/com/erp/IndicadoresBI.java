package com.erp;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IndicadoresBI {

    public static class Indicador {
        public final String chave;     // chave de idioma do rótulo
        public final String valor;     // já formatado para a tela
        public final String situacao;  // "bom", "atencao" ou "" (neutro)

        Indicador(String chave, String valor, String situacao) {
            this.chave = chave;
            this.valor = valor;
            this.situacao = situacao;
        }
    }

    private static final int JANELA = 30;

    public static List<Indicador> calcular(ColetaBI.Dados d) {
        List<Indicador> lista = new ArrayList<>();

        lista.add(new Indicador("bi.faturamento", Formato.moeda(d.faturamento), ""));

        BigDecimal ticket = (d.quantidadePedidos == 0) ? BigDecimal.ZERO
                : d.faturamento.divide(BigDecimal.valueOf(d.quantidadePedidos), 2,
                        RoundingMode.HALF_UP);
        lista.add(new Indicador("bi.ticket", Formato.moeda(ticket), ""));
        lista.add(new Indicador("bi.pedidos", String.valueOf(d.quantidadePedidos), ""));
        lista.add(new Indicador("bi.estoque.valor", Formato.moeda(d.valorEmEstoque), ""));

        double giro = (d.valorEmEstoque.signum() == 0) ? 0
                : d.faturamento.doubleValue() / d.valorEmEstoque.doubleValue();
        lista.add(new Indicador("bi.giro", Formato.numero(giro, 2) + "x",
                giro < 1 ? "atencao" : "bom"));
        lista.add(new Indicador("bi.receber", Formato.moeda(d.aReceber), ""));
        lista.add(new Indicador("bi.pagar", Formato.moeda(d.aPagar), ""));
        BigDecimal saldo = d.aReceber.subtract(d.aPagar);
        lista.add(new Indicador("bi.saldo", Formato.moeda(saldo),
                saldo.signum() < 0 ? "atencao" : "bom"));
        lista.add(new Indicador("bi.zerados", d.produtosZerados + " / " + d.produtosCadastrados,
                d.produtosZerados > d.produtosCadastrados / 4 ? "atencao" : "bom"));
        lista.add(crescimento(d));

        return lista;
    }

    private static Indicador crescimento(ColetaBI.Dados d) {
        if (d.porDia.isEmpty()) {
            return new Indicador("bi.crescimento", "-", "");
        }
        LocalDate fim = d.porDia.lastKey();
        LocalDate meio = fim.minusDays(JANELA);
        LocalDate inicio = fim.minusDays(JANELA * 2L);

        BigDecimal recente = somar(d, meio, fim);
        BigDecimal anterior = somar(d, inicio, meio);

        if (anterior.signum() == 0) {
            return new Indicador("bi.crescimento", "-", "");
        }
        double variacao = (recente.doubleValue() - anterior.doubleValue())
                / anterior.doubleValue() * 100;
        return new Indicador("bi.crescimento",
                (variacao >= 0 ? "+" : "") + Formato.numero(variacao, 1) + "%",
                variacao >= 0 ? "bom" : "atencao");
    }

    private static BigDecimal somar(ColetaBI.Dados d, LocalDate de, LocalDate ate) {
        BigDecimal total = BigDecimal.ZERO;
        for (Map.Entry<LocalDate, BigDecimal> e : d.porDia.subMap(de, false, ate, true).entrySet()) {
            total = total.add(e.getValue());
        }
        return total;
    }

    public static void imprimir() throws IOException {
        ColetaBI.Dados d = ColetaBI.obter();

        Console.titulo(Idioma.t("bi.titulo"));

        if (d.quantidadePedidos == 0) {
            Console.aviso(Idioma.t("bi.sem.dados"));
            return;
        }

        Console.linha();
        for (Indicador i : calcular(d)) {
            String marca = switch (i.situacao) {
                case "atencao" -> " [!]";
                case "bom" -> " [ok]";
                default -> "";
            };
            System.out.printf("%-34s %18s%s%n", Idioma.t(i.chave), i.valor, marca);
        }
        Console.linha();

        CurvaABC.imprimir(d);
        PrevisaoBI.imprimir(d);

        System.out.println();
        boolean cache = ColetaBI.ultimaLeituraVeioDoCache();
        System.out.printf(Idioma.t("bi.origem") + "%n",
                cache ? Idioma.t("bi.origem.cache")
                        : Idioma.t("bi.origem.calculo",
                                Formato.numero(ColetaBI.msDaUltimaLeitura(), 1)));
        LogAuditoria.registrar("SISTEMA", "PAINEL_BI",
                "Pedidos=" + d.quantidadePedidos + ", Cache=" + cache);
    }
}
