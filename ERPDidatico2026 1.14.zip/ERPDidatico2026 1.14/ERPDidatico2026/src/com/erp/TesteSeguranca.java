package com.erp;

import java.util.HashSet;
import java.util.Set;

public class TesteSeguranca {

    private static int passou = 0;
    private static int falhou = 0;

    public static void main(String[] args) {
        Console.linha();
        System.out.println("TESTE DE SEGURANÇA - ARMAZENAMENTO DE SENHAS");
        Console.linha();

        testarFormato();
        testarSalDiferente();
        testarConferencia();
        testarCompatibilidade();
        testarCusto();

        Console.linha();
        System.out.printf("%d conferências, %d de acordo, %d FORA DO ESPERADO%n",
                passou + falhou, passou, falhou);
        if (falhou == 0) {
            System.out.println("A correção está de pé. Senhas antigas continuam entrando");
            System.out.println("e são migradas sozinhas no login.");
        } else {
            System.out.println("ATENÇÃO: não suba esta versão. Alguém pode ficar sem acesso.");
        }
        Console.linha();
    }

    private static void testarFormato() {
        titulo("FORMATO DO CAMPO GRAVADO");

        String campo = Seguranca.protegerSenha("senhaDeTeste123");
        System.out.println("   exemplo: " + encurtar(campo));

        String[] partes = campo.split("\\$");
        conferir("tem as quatro partes separadas por $", 4, partes.length);
        conferir("começa com a marca do algoritmo", "pbkdf2", partes[0]);
        conferir("registra as repetições usadas",
                String.valueOf(Seguranca.getRepeticoes()), partes[1]);
        conferirVerdadeiro("o sal não está vazio", !partes[2].isEmpty());
        conferirVerdadeiro("a senha não aparece em lugar nenhum do campo",
                !campo.contains("senhaDeTeste123"));
    }

    private static void testarSalDiferente() {
        titulo("SAL ALEATÓRIO POR USUÁRIO");

        Set<String> campos = new HashSet<>();
        for (int i = 0; i < 20; i++) {
            campos.add(Seguranca.protegerSenha("admin123"));
        }
        conferir("20 pessoas com a senha \"admin123\" geram 20 campos distintos",
                20, campos.size());

        System.out.println("   antes (SHA-256 puro), as 20 dariam este mesmo valor:");
        System.out.println("   " + encurtar(Seguranca.hashAntigo("admin123")));
        System.out.println("   esse hash é pesquisável na internet. O novo não é.");
    }

    private static void testarConferencia() {
        titulo("CONFERÊNCIA DA SENHA");

        String campo = Seguranca.protegerSenha("Correta#2026");
        conferirVerdadeiro("a senha certa entra", Seguranca.conferir("Correta#2026", campo));
        conferirFalso("senha errada não entra", Seguranca.conferir("Errada#2026", campo));
        conferirFalso("quase certa não entra", Seguranca.conferir("Correta#2025", campo));
        conferirFalso("diferença de maiúscula não entra", Seguranca.conferir("correta#2026", campo));
        conferirFalso("senha vazia não entra", Seguranca.conferir("", campo));
        conferirFalso("campo corrompido nega em vez de quebrar",
                Seguranca.conferir("qualquer", "pbkdf2$nao$e$numero"));
        conferirFalso("campo vazio nega", Seguranca.conferir("qualquer", ""));
    }

    private static void testarCompatibilidade() {
        titulo("COMPATIBILIDADE COM O FORMATO ANTIGO");

        String campoAntigo = Seguranca.hashAntigo("admin123");
        conferirVerdacompat("conta antiga ainda consegue entrar",
                Seguranca.conferir("admin123", campoAntigo));
        conferirFalso("conta antiga com senha errada não entra",
                Seguranca.conferir("outra", campoAntigo));
        conferirVerdadeiro("o sistema reconhece que o campo antigo precisa migrar",
                Seguranca.precisaAtualizar(campoAntigo));
        conferirFalso("campo novo não precisa migrar de novo",
                Seguranca.precisaAtualizar(Seguranca.protegerSenha("qualquer")));

        System.out.println("   Ou seja: no dia da atualização ninguém fica trancado para fora,");
        System.out.println("   e cada conta migra sozinha no primeiro login.");
    }

    private static void testarCusto() {
        titulo("CUSTO DO CÁLCULO");

        long inicio = System.nanoTime();
        int repeticoes = 10;
        for (int i = 0; i < repeticoes; i++) {
            Seguranca.protegerSenha("medindo" + i);
        }
        double ms = (System.nanoTime() - inicio) / 1_000_000.0 / repeticoes;

        System.out.printf("   %-42s %s ms%n", "tempo de um cálculo PBKDF2",
                Formato.numero(ms, 1));
        System.out.printf("   %-42s %s%n", "repetições por cálculo", Seguranca.getRepeticoes());

        long inicioAntigo = System.nanoTime();
        for (int i = 0; i < 10000; i++) {
            Seguranca.hashAntigo("medindo" + i);
        }
        double msAntigo = (System.nanoTime() - inicioAntigo) / 1_000_000.0 / 10000;
        System.out.printf("   %-42s %s ms%n", "tempo de um SHA-256 puro (o formato antigo)",
                Formato.numero(msAntigo, 4));

        if (msAntigo > 0) {
            System.out.printf("   %-42s %sx%n", "quanto um ataque de força bruta encareceu",
                    Formato.numero(ms / msAntigo, 0));
        }
        System.out.println();
        System.out.println("   Para quem faz login, a diferença é imperceptível.");
        System.out.println("   Para quem tenta adivinhar bilhões de senhas, muda tudo.");

        conferirVerdadeiro("o cálculo é lento o bastante para atrapalhar ataque", ms > 10);
        conferirVerdadeiro("o cálculo é rápido o bastante para não atrapalhar o login", ms < 1000);
    }

    private static void titulo(String texto) {
        System.out.println();
        System.out.println(">>> " + texto);
        Console.linha();
    }

    private static void conferir(String caso, Object esperado, Object obtido) {
        registrar(caso, esperado.equals(obtido), String.valueOf(obtido));
    }

    private static void conferirVerdadeiro(String caso, boolean obtido) {
        registrar(caso, obtido, obtido ? "sim" : "não");
    }

    private static void conferirVerdacompat(String caso, boolean obtido) {
        conferirVerdadeiro(caso, obtido);
    }

    private static void conferirFalso(String caso, boolean obtido) {
        registrar(caso, !obtido, obtido ? "entrou" : "negou");
    }

    private static void registrar(String caso, boolean bateu, String observado) {
        if (bateu) {
            passou++;
        } else {
            falhou++;
        }
        System.out.printf("  %-5s %-58s %s%n", bateu ? "[ok]" : "[!!]", caso, observado);
    }

    private static String encurtar(String texto) {
        return texto.length() <= 58 ? texto : texto.substring(0, 55) + "...";
    }
}
