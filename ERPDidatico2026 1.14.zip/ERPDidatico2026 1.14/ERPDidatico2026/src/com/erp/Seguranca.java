package com.erp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;

public class Seguranca {

    private static final String MARCA = "pbkdf2";
    private static final String ALGORITMO = "PBKDF2WithHmacSHA256";
    private static final int REPETICOES = 120_000;
    private static final int TAMANHO_SAL = 16;  // bytes
    private static final int TAMANHO_HASH = 256; // bits

    private static final SecureRandom SORTEIO = new SecureRandom();

    public static String protegerSenha(String senha) {
        byte[] sal = new byte[TAMANHO_SAL];
        SORTEIO.nextBytes(sal);
        byte[] hash = calcular(senha, sal, REPETICOES);
        return MARCA + "$" + REPETICOES + "$"
                + Base64.getEncoder().encodeToString(sal) + "$"
                + Base64.getEncoder().encodeToString(hash);
    }

    public static boolean conferir(String senhaDigitada, String campoGravado) {
        if (campoGravado == null || campoGravado.isEmpty()) {
            return false;
        }

        if (!campoGravado.startsWith(MARCA + "$")) {
            return iguaisSemVazamentoDeTempo(hashAntigo(senhaDigitada), campoGravado);
        }

        String[] partes = campoGravado.split("\\$");
        if (partes.length != 4) {
            return false;
        }
        try {
            int repeticoes = Integer.parseInt(partes[1]);
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] esperado = Base64.getDecoder().decode(partes[3]);
            byte[] obtido = calcular(senhaDigitada, sal, repeticoes);
            return MessageDigest.isEqual(esperado, obtido);
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static boolean precisaAtualizar(String campoGravado) {
        if (campoGravado == null || !campoGravado.startsWith(MARCA + "$")) {
            return true;
        }
        String[] partes = campoGravado.split("\\$");
        return partes.length != 4 || Integer.parseInt(partes[1]) < REPETICOES;
    }

    private static byte[] calcular(String senha, byte[] sal, int repeticoes) {
        try {
            PBEKeySpec spec = new PBEKeySpec(senha.toCharArray(), sal, repeticoes, TAMANHO_HASH);
            return SecretKeyFactory.getInstance(ALGORITMO).generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException("PBKDF2 indisponível nesta instalação do Java", e);
        }
    }

    public static String hashAntigo(String senha) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(senha.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 indisponível", e);
        }
    }

    private static boolean iguaisSemVazamentoDeTempo(String a, String b) {
        return MessageDigest.isEqual(
                a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    public static int getRepeticoes() {
        return REPETICOES;
    }

    public static String getMarca() {
        return MARCA;
    }
}
