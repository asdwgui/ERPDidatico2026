package com.erp;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

public class VarreduraSeguranca {
    private static final String PASTA_FONTE = "ERPDidatico2026/src/com/erp";
    private static final String PASTA_FONTE_ALTERNATIVA = "src/com/erp";

    private static final String CRITICA = "CRÍTICA";
    private static final String ALTA = "ALTA";
    private static final String MEDIA = "MÉDIA";
    private static final String BAIXA = "BAIXA";
    private static final List<Achado> ACHADOS = new ArrayList<>();

    public static class Achado {
        final String severidade, titulo, detalhe, situacao;
        Achado(String severidade, String titulo, String detalhe, String situacao) {
            this.severidade = severidade;
            this.titulo = titulo;
            this.detalhe = detalhe;
            this.situacao = situacao;
        }
    }

    private static String t(String chave, Object... valores) {
        return Idioma.t(chave, valores);
    }

    public static void main(String[] args) throws IOException {
        ACHADOS.clear();
        Console.linha();
        System.out.println(t("seg.varredura.titulo"));
        System.out.println(t("seg.varredura.executada", Formato.agoraParaArquivo()));
        Console.linha();
        inventarioDeDependencias();
        conferirSenhas();
        conferirSenhasPadrao();
        conferirDadosPessoais();
        conferirTrilhaDeAuditoria();
        conferirBloqueio();
        relatorio();
    }

    private static void inventarioDeDependencias() throws IOException {
        Path pasta = Path.of(PASTA_FONTE);
        if (!Files.isDirectory(pasta)) pasta = Path.of(PASTA_FONTE_ALTERNATIVA);
        System.out.println();
        System.out.println(t("seg.varredura.secao1"));
        Console.linha();
        if (!Files.isDirectory(pasta)) {
            Console.aviso(t("seg.varredura.fonte.nao_encontrada"));
            System.out.println(t("seg.varredura.fonte.procurada", PASTA_FONTE, PASTA_FONTE_ALTERNATIVA));
            return;
        }

        TreeMap<String, TreeSet<String>> porPacote = new TreeMap<>();
        List<String> terceiros = new ArrayList<>();
        int arquivos = 0;
        try (var caminhos = Files.walk(pasta)) {
            for (Path arquivo : caminhos.filter(p -> Files.isRegularFile(p) && p.toString().endsWith(".java")).toList()) {
                arquivos++;
                for (String linha : Files.readAllLines(arquivo, StandardCharsets.UTF_8)) {
                    String limpa = linha.trim();
                    if (!limpa.startsWith("import ")) continue;
                    String pacote = limpa.substring(7).replace(";", "").replace("static ", "").trim();
                    String raiz = pacote.contains(".") ? pacote.substring(0, pacote.indexOf('.')) : pacote;
                    if (ehDoJava(raiz)) porPacote.computeIfAbsent(raiz, k -> new TreeSet<>()).add(pacote);
                    else if (!pacote.startsWith("com.erp")) terceiros.add(pacote + "  (" + arquivo.getFileName() + ")");
                }
            }
        }

        System.out.printf("%-34s %d%n", t("seg.varredura.arquivos"), arquivos);
        System.out.printf("%-34s %s%n", t("seg.varredura.java"), System.getProperty("java.version"));
        System.out.println();
        System.out.println(t("seg.varredura.pacotes"));
        for (var e : porPacote.entrySet())
            System.out.printf("      %-12s %2d %s%n", e.getKey() + ".*", e.getValue().size(), t("seg.varredura.pacote.origem"));

        System.out.println();
        if (terceiros.isEmpty()) {
            Console.ok(t("seg.varredura.sem.terceiros"));
            System.out.println(t("seg.varredura.superficie.zero"));
            System.out.println(t("seg.varredura.sem.log4j"));
            registrar(BAIXA, t("seg.achado.sem_dependencias.titulo"), t("seg.achado.sem_dependencias.detalhe"), "ACEITO");
        } else {
            Console.aviso(t("seg.varredura.terceiros", terceiros.size()));
            for (String terceiro : terceiros) System.out.println("      " + terceiro);
            registrar(ALTA, t("seg.achado.dependencias.titulo"), t("seg.achado.dependencias.detalhe", terceiros.size()), "ABERTO");
        }
        System.out.println();
        System.out.println(t("seg.varredura.java.cves"));
        System.out.println(t("seg.varredura.politica"));
    }

    private static boolean ehDoJava(String raiz) {
        return raiz.equals("java") || raiz.equals("javax") || raiz.equals("jdk") || raiz.equals("sun");
    }

    private static void conferirSenhas() throws IOException {
        System.out.println(); System.out.println(t("seg.varredura.secao2")); Console.linha();
        Path arquivo = Path.of("usuarios.txt");
        if (!Files.exists(arquivo)) { Console.aviso(t("seg.varredura.usuarios.nao_encontrado")); return; }
        int antigas = 0, novas = 0;
        List<String> nomesAntigos = new ArrayList<>();
        for (String linha : Files.readAllLines(arquivo, StandardCharsets.UTF_8)) {
            if (linha.isBlank()) continue;
            String[] p = linha.split(","); if (p.length < 2) continue;
            if (p[1].startsWith(Seguranca.getMarca() + "$")) novas++;
            else { antigas++; nomesAntigos.add(p[0]); }
        }
        System.out.printf("%-34s %d%n", t("seg.varredura.senhas.protegidas"), novas);
        System.out.printf("%-34s %d%n", t("seg.varredura.senhas.antigas"), antigas);
        if (antigas > 0) {
            System.out.println(t("seg.varredura.contas.pendentes", String.join(", ", nomesAntigos)));
            registrar(CRITICA, t("seg.achado.hash.titulo"), t("seg.achado.hash.detalhe", antigas), "EM MIGRAÇÃO");
        } else {
            Console.ok(t("seg.varredura.senhas.todas_protegidas", Seguranca.getRepeticoes()));
            registrar(CRITICA, t("seg.achado.hash.titulo"), t("seg.achado.hash.corrigido"), "CORRIGIDO");
        }
    }

    private static void conferirSenhasPadrao() throws IOException {
        System.out.println(); System.out.println(t("seg.varredura.secao3")); Console.linha();
        Path arquivo = Path.of("usuarios.txt"); if (!Files.exists(arquivo)) return;
        String[][] suspeitas = {{"admin", "admin123"}, {"operador", "operador123"}, {"admin", "admin"}, {"admin", "123456"}};
        List<String> encontradas = new ArrayList<>();
        for (String linha : Files.readAllLines(arquivo, StandardCharsets.UTF_8)) {
            String[] p = linha.split(","); if (p.length < 2) continue;
            for (String[] s : suspeitas) if (p[0].equalsIgnoreCase(s[0]) && Seguranca.conferir(s[1], p[1])) { encontradas.add(p[0]); break; }
        }
        if (encontradas.isEmpty()) Console.ok(t("seg.varredura.sem_senha_padrao"));
        else {
            String contas = String.join(", ", encontradas);
            Console.aviso(t("seg.varredura.senha_padrao", contas));
            registrar(ALTA, t("seg.achado.senha_padrao.titulo"), t("seg.achado.senha_padrao.detalhe", contas), "ABERTO");
        }
    }

    private static void conferirDadosPessoais() throws IOException {
        System.out.println(); System.out.println(t("seg.varredura.secao4")); Console.linha();
        Path arquivo = Path.of("pessoas.txt");
        if (!Files.exists(arquivo)) { Console.aviso(t("seg.varredura.pessoas.nao_encontrado")); return; }
        long pessoas = Files.readAllLines(arquivo, StandardCharsets.UTF_8).stream().filter(l -> !l.isBlank()).count();
        System.out.printf("%-34s %d%n", t("seg.varredura.pessoas.cadastradas"), pessoas);
        System.out.printf("%-34s %s%n", t("seg.varredura.formato"), t("seg.varredura.texto_puro"));
        Console.aviso(t("seg.varredura.pessoas.exposicao"));
        registrar(ALTA, t("seg.achado.dados.titulo"), t("seg.achado.dados.detalhe", pessoas), "ABERTO");
    }

    private static void conferirTrilhaDeAuditoria() {
        System.out.println(); System.out.println(t("seg.varredura.secao5")); Console.linha();
        Path log = Path.of("auditoria.log");
        if (!Files.exists(log)) {
            Console.aviso(t("seg.varredura.log.inexistente"));
            registrar(MEDIA, t("seg.achado.log.ausente.titulo"), t("seg.achado.log.ausente.detalhe"), "ABERTO"); return;
        }
        try {
            long linhas = Files.readAllLines(log, StandardCharsets.UTF_8).size();
            System.out.printf("%-34s %d%n", t("seg.varredura.eventos"), linhas);
            Console.ok(t("seg.varredura.trilha.presente"));
        } catch (IOException e) { Console.aviso(t("seg.varredura.log.leitura_falhou")); }
        registrar(MEDIA, t("seg.achado.log.titulo"), t("seg.achado.log.detalhe"), "ABERTO");
    }

    private static void conferirBloqueio() {
        System.out.println(); System.out.println(t("seg.varredura.secao6")); Console.linha();
        System.out.printf("%-34s %d %s%n", t("seg.varredura.limite"), BloqueioLogin.getLimite(), t("seg.varredura.tentativas"));
        System.out.printf("%-34s %d %s%n", t("seg.varredura.tempo_bloqueio"), BloqueioLogin.getMinutos(), t("seg.varredura.minutos"));
        var comErros = BloqueioLogin.contasComErros();
        if (comErros.isEmpty()) Console.ok(t("seg.varredura.sem_erros"));
        else {
            Console.aviso(t("seg.varredura.erros.recentes"));
            comErros.forEach((conta, erros) -> System.out.println("      " + conta + ": " + t("seg.varredura.erros.contagem", erros)));
        }
        registrar(ALTA, t("seg.achado.forca_bruta.titulo"), t("seg.achado.forca_bruta.detalhe", BloqueioLogin.getLimite(), BloqueioLogin.getMinutos()), "CORRIGIDO");
    }

    private static void registrar(String severidade, String titulo, String detalhe, String situacao) {
        ACHADOS.add(new Achado(severidade, titulo, detalhe, situacao));
    }

    private static void relatorio() {
        System.out.println(); Console.linha(); System.out.println(t("seg.varredura.resumo")); Console.linha();
        String[] ordem = {CRITICA, ALTA, MEDIA, BAIXA}; int abertos = 0;
        for (String severidade : ordem) for (Achado a : ACHADOS) {
            if (!a.severidade.equals(severidade)) continue;
            if (a.situacao.equals("ABERTO")) abertos++;
            System.out.println();
            System.out.printf("[%s] %s%n", t("seg.severidade." + chaveSeveridade(a.severidade)), a.titulo);
            System.out.printf("   %s: %s%n", t("seg.varredura.situacao"), t("seg.situacao." + chaveSituacao(a.situacao)));
            for (String linha : quebrar(a.detalhe, 70)) System.out.println("   " + linha);
        }
        System.out.println(); Console.linha();
        System.out.println(t("seg.varredura.total", ACHADOS.size(), abertos));
        System.out.println(t("seg.varredura.falha_critica")); Console.linha();
    }

    private static String chaveSeveridade(String s) {
        if (CRITICA.equals(s)) return "critica"; if (ALTA.equals(s)) return "alta";
        if (MEDIA.equals(s)) return "media"; return "baixa";
    }
    private static String chaveSituacao(String s) {
        if ("ABERTO".equals(s)) return "aberto"; if ("CORRIGIDO".equals(s)) return "corrigido";
        if ("ACEITO".equals(s)) return "aceito"; return "migracao";
    }
    private static List<String> quebrar(String texto, int largura) {
        List<String> linhas = new ArrayList<>(); StringBuilder atual = new StringBuilder();
        for (String palavra : texto.split(" ")) {
            if (atual.length() > 0 && atual.length() + palavra.length() + 1 > largura) { linhas.add(atual.toString()); atual = new StringBuilder(); }
            if (atual.length() > 0) atual.append(' '); atual.append(palavra);
        }
        if (atual.length() > 0) linhas.add(atual.toString()); return linhas;
    }
}
