package com.erp;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class BloqueioLogin {

    private static final String ARQUIVO = "seguranca_tentativas.txt";
    private static final int TENTATIVAS_ATE_BLOQUEAR = 5;
    private static final int MINUTOS_BLOQUEADO = 15;

    private static final DateTimeFormatter FORMATO =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static class Registro {
        int erros;
        LocalDateTime ultimoErro;
    }

    private static final Map<String, Registro> REGISTROS = new LinkedHashMap<>();
    private static boolean carregado = false;

    public static long minutosBloqueado(String username) {
        carregar();
        Registro r = REGISTROS.get(username);
        if (r == null || r.erros < TENTATIVAS_ATE_BLOQUEAR || r.ultimoErro == null) {
            return 0;
        }
        long passados = Duration.between(r.ultimoErro, LocalDateTime.now()).toMinutes();
        long faltam = MINUTOS_BLOQUEADO - passados;
        if (faltam <= 0) {
            REGISTROS.remove(username);
            gravar();
            return 0;
        }
        return faltam;
    }

    public static boolean estaBloqueado(String username) {
        return minutosBloqueado(username) > 0;
    }

    public static void registrarErro(String username) {
        carregar();
        Registro r = REGISTROS.computeIfAbsent(username, k -> new Registro());
        r.erros++;
        r.ultimoErro = LocalDateTime.now();
        gravar();

        if (r.erros == TENTATIVAS_ATE_BLOQUEAR) {
            LogAuditoria.registrar(username, "CONTA_BLOQUEADA",
                    TENTATIVAS_ATE_BLOQUEAR + " tentativas erradas seguidas");
        }
    }

    public static void registrarAcerto(String username) {
        carregar();
        if (REGISTROS.remove(username) != null) {
            gravar();
        }
    }

    public static int tentativasRestantes(String username) {
        carregar();
        Registro r = REGISTROS.get(username);
        int usadas = (r == null) ? 0 : r.erros;
        return Math.max(0, TENTATIVAS_ATE_BLOQUEAR - usadas);
    }

    public static int getLimite() {
        return TENTATIVAS_ATE_BLOQUEAR;
    }

    public static int getMinutos() {
        return MINUTOS_BLOQUEADO;
    }

    public static Map<String, Integer> contasComErros() {
        carregar();
        Map<String, Integer> resumo = new LinkedHashMap<>();
        for (Map.Entry<String, Registro> e : REGISTROS.entrySet()) {
            resumo.put(e.getKey(), e.getValue().erros);
        }
        return resumo;
    }

    private static void carregar() {
        if (carregado) {
            return;
        }
        carregado = true;
        Path caminho = Path.of(ARQUIVO);
        if (!Files.exists(caminho)) {
            return;
        }
        try {
            for (String linha : Files.readAllLines(caminho, StandardCharsets.UTF_8)) {
                String[] p = linha.split(",");
                if (p.length < 3) {
                    continue;
                }
                Registro r = new Registro();
                r.erros = Integer.parseInt(p[1].trim());
                r.ultimoErro = LocalDateTime.parse(p[2].trim(), FORMATO);
                REGISTROS.put(p[0], r);
            }
        } catch (IOException | RuntimeException e) {
            REGISTROS.clear();
        }
    }

    private static void gravar() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO))) {
            for (Map.Entry<String, Registro> e : REGISTROS.entrySet()) {
                writer.write(e.getKey() + "," + e.getValue().erros + ","
                        + e.getValue().ultimoErro.format(FORMATO));
                writer.newLine();
            }
        } catch (IOException e) {
            Console.aviso("Não foi possível gravar o controle de tentativas.");
        }
    }
}
